function createSParametersBlock(Snew, f, varargin)
%sysname = 'SParametersBlock';
%new_system(sysname)

sysname = varargin{1};
N = size(Snew,1);
bx = 20;
by = 40;
s = 100;
%% Add blocks
for m = N:-1:1
    y = (m-1)*s;
    for n = 1:m
        blockname = [sysname '/S_' num2str(n) '_' num2str(m)];
        add_block('simrfV2elements/S-parameters', blockname);
        set_param(blockname, 'DataSource', 'Network-parameters');
        if n~=m
            set_param(blockname, 'InternalGrounding', 0);
        end
        set_param(blockname, 'Sparam', ['Snew(' num2str(m) ',' num2str(n) ',:)']);
        set_param(blockname, 'SparamFreq', 'f');
        set_param(blockname, 'FitTol', '-70');
        x = (n-1)*s;
        set_param(blockname, 'Position', [x+(s-bx)/2 y+(s-by)/2 x+(s+bx)/2 y+(s+by)/2]);
        p = get_param(blockname, 'PortHandles');
        if n~=m
            portPos1 = get_param(p.LConn(1), 'Position');
            portPos2 = get_param(p.LConn(2), 'Position');
            add_line(sysname, [x+bx/2     y+by; portPos1]);
            add_line(sysname, [x+(s+bx)/2 y+s;  portPos2]);
        else
            portPos = get_param(p.LConn, 'Position');
            add_line(sysname, [x+bx/2     y+s/2; portPos]);
        end
    end
end

%% Find offset for connection port
blockname = [sysname '/TestPort'];
add_block('simrfV2util1/Connection Port', blockname);
set_param(blockname, 'Position', [0 0 bx by]);
p = get_param(blockname, 'PortHandles');
portOffset = get_param(p.RConn(1), 'Position');
delete_block(blockname);

%% Add vertical lines (inputs)
y = -s/2;
for n = 1:N
    x = (n-1)*s;
    blockname = [sysname '/' num2str(n)];
    add_block('simrfV2util1/Connection Port', blockname);
    set_param(blockname, 'Position', [x y x+bx y+by] - [portOffset portOffset]);
    set_param(blockname, 'Port', num2str(2*n-1));
    set_param(blockname, 'Side', 'Left');
    add_line(sysname, [x          y; x+bx/2 n*s+y]);
    add_line(sysname, [x+bx/2 n*s+y; x+bx/2 n*s+by]);
    for m = n:N-2
        add_line(sysname, [x+bx/2 m*s+by; x+bx/2 (m+1)*s+by]);
    end
end
%% Add horizontal lines (outputs)
x = (s+bx)/2;
for m = 2:N
    y = m*s;
    for n = 0:m-2
        if n==m-2
            add_line(sysname, [n*s+x y; (n+1)*s+x-s/2 y]);
        else
            add_line(sysname, [n*s+x y; (n+1)*s+x y]);
        end
    end
end
open_system(sysname)
