%% Define system variables
F0 = 5e9;
fmin = F0 - .05*F0;
fmax = F0 + .05*F0;
f = linspace(fmin, fmax, 201);
c = physconst('lightspeed');
lambda = c/F0;
%% Create and tune Resonant Dipole
d = dipole;
d.Length = lambda/2;
d.Width = lambda/200;
minX = 0.0001;          % Minimum value of reactance to achieve
trim = 0.0005;          % The amount to shorten the length at each iteration
resonant_dipole = dipole_tuner(d,F0,fmin,fmax,minX,trim)
P_antenna = pattern(d, F0);
%% Create linear array and analyze it
l = linearArray;
l.NumElements = 8;
l.Element = d;
l.ElementSpacing = 0.5*lambda;
%% Impedance and coupling of the array elements
figure;
impedance(l, f)
s = sparameters(l,f);
S_antenna = s.Parameters;
% Impedance = (j*omega*L)
L = -imag(impedance(l, F0))./(2*pi*F0);
%% 3D and 2D pattern visualization
figure
pattern(l, F0);
figure
p1 = patternAzimuth(l, F0, 0);
P = polarpattern(p1);
%% Array design with pattern superposition
u = phased.ULA;
u.NumElements = 8;
u.Element = d;
u.ElementSpacing = 0.5*lambda;
u.ArrayAxis = 'x';
%% 3D and 2D pattern visualization
figure;
pattern(u, F0);
p2 = patternAzimuth(u, F0, 0);
add(P,p2)
P.MagnitudeLim = [-40 20];
P.LegendLabels ={'Full wave', 'Pattern superposition'};
%% Save data and run simulink model
%save('AntennaArrayData.mat', 'F0', 'f', 'lambda', 'L', 'P_antenna', 'S_antenna')
open('MIMOCommunicationsSystem');