#include "__cf_MIMOCommunicationsSystem.h"
#include <math.h>
#include "MIMOCommunicationsSystem_acc.h"
#include "MIMOCommunicationsSystem_acc_private.h"
#include <stdio.h>
#include "slexec_vm_simstruct_bridge.h"
#include "slexec_vm_zc_functions.h"
#include "slexec_vm_lookup_functions.h"
#include "simstruc.h"
#include "fixedpoint.h"
#define CodeFormat S-Function
#define AccDefine1 Accelerator_S-Function
#include "simtarget/slAccSfcnBridge.h"
void ke3md013gp ( creal_T ocxhfu3ubv , creal_T * mst31g0w1q , hfcskoczds *
localP ) { mst31g0w1q -> re = localP -> P_0 * ocxhfu3ubv . re ; mst31g0w1q ->
im = localP -> P_0 * ocxhfu3ubv . im ; } void byroleie1u ( SimStruct * const
S ) { } void bgnxdoxzrs ( creal_T pw4lzlzi22 , creal_T * agqgbjhu0x ,
d3vabf3din * localB , mgpn43wxg5 * localP ) { real_T opxmwfeha2 ; real_T
d1dzq3dmf0 ; real_T gieco3naah ; real_T gwdu1v3rxt ; gieco3naah = localP ->
P_1 * pw4lzlzi22 . re ; gwdu1v3rxt = localP -> P_1 * pw4lzlzi22 . im ;
opxmwfeha2 = muDoubleScalarHypot ( gieco3naah , gwdu1v3rxt ) ; if (
opxmwfeha2 > localP -> P_2 ) { d1dzq3dmf0 = localP -> P_2 ; } else if (
opxmwfeha2 < localP -> P_3 ) { d1dzq3dmf0 = localP -> P_3 ; } else {
d1dzq3dmf0 = opxmwfeha2 ; } opxmwfeha2 = localP -> P_5 * opxmwfeha2 + localB
-> gopabpt5xb ; opxmwfeha2 = muDoubleScalarLog10 ( opxmwfeha2 * opxmwfeha2 *
localP -> P_7 ) * localP -> P_8 + localB -> djbeaaxtif ; if ( opxmwfeha2 >
localP -> P_10 ) { opxmwfeha2 = localP -> P_10 ; } else { if ( opxmwfeha2 <
localP -> P_11 ) { opxmwfeha2 = localP -> P_11 ; } } opxmwfeha2 = localP ->
P_12 * opxmwfeha2 + muDoubleScalarAtan2 ( gwdu1v3rxt , gieco3naah ) ; if ( (
d1dzq3dmf0 < 0.0 ) && ( localB -> hycoygaup5 > muDoubleScalarFloor ( localB
-> hycoygaup5 ) ) ) { gieco3naah = - muDoubleScalarPower ( - d1dzq3dmf0 ,
localB -> hycoygaup5 ) ; } else { gieco3naah = muDoubleScalarPower (
d1dzq3dmf0 , localB -> hycoygaup5 ) ; } agqgbjhu0x -> re = ( d1dzq3dmf0 -
localP -> P_4 * gieco3naah ) * muDoubleScalarCos ( opxmwfeha2 ) * localP ->
P_13 ; agqgbjhu0x -> im = ( d1dzq3dmf0 - localP -> P_4 * gieco3naah ) *
muDoubleScalarSin ( opxmwfeha2 ) * localP -> P_13 ; } void bgnxdoxzrsTID3 (
d3vabf3din * localB , mgpn43wxg5 * localP ) { localB -> hycoygaup5 = localP
-> P_0 ; localB -> gopabpt5xb = localP -> P_6 ; localB -> djbeaaxtif = localP
-> P_9 ; } void c5xbm4agjj ( SimStruct * const S ) { } void e1euhyqxus (
creal_T flnjiif2vq , creal_T * lnap4crgom , jr2jrb1kva * localB , gk4zctqeq4
* localP ) { real_T lt13pkvcx5 ; real_T j2uovcoilg ; real_T cw4c2hbzhn ;
real_T gflbazfxje ; cw4c2hbzhn = localP -> P_0 * flnjiif2vq . re ; gflbazfxje
= localP -> P_0 * flnjiif2vq . im ; lt13pkvcx5 = muDoubleScalarHypot (
cw4c2hbzhn , gflbazfxje ) ; j2uovcoilg = localP -> P_1 * lt13pkvcx5 + localB
-> oi1bn1f5os ; j2uovcoilg = muDoubleScalarLog10 ( j2uovcoilg * j2uovcoilg *
localP -> P_3 ) * localP -> P_4 + localB -> baal5cg1qy ; if ( j2uovcoilg >
localP -> P_6 ) { j2uovcoilg = localP -> P_6 ; } else { if ( j2uovcoilg <
localP -> P_7 ) { j2uovcoilg = localP -> P_7 ; } } j2uovcoilg = localP -> P_8
* j2uovcoilg + muDoubleScalarAtan2 ( gflbazfxje , cw4c2hbzhn ) ; lnap4crgom
-> re = muDoubleScalarTanh ( lt13pkvcx5 ) * muDoubleScalarCos ( j2uovcoilg )
* localP -> P_9 ; lnap4crgom -> im = muDoubleScalarTanh ( lt13pkvcx5 ) *
muDoubleScalarSin ( j2uovcoilg ) * localP -> P_9 ; } void e1euhyqxusTID3 (
jr2jrb1kva * localB , gk4zctqeq4 * localP ) { localB -> oi1bn1f5os = localP
-> P_2 ; localB -> baal5cg1qy = localP -> P_5 ; } void ow25lbjp2a ( SimStruct
* const S ) { } void ehval41szi ( creal_T fi2bbpc1fs , creal_T * cxo4thuzp3 ,
dctlrdbhva * localB , f0ewbxt5x2 * localP ) { real_T bs2p213prd ; real_T
gxfvl5ry4o ; real_T h2ovgwbnou ; real_T a4dh5skyzq ; h2ovgwbnou = localP ->
P_1 * fi2bbpc1fs . re ; a4dh5skyzq = localP -> P_1 * fi2bbpc1fs . im ;
bs2p213prd = muDoubleScalarHypot ( h2ovgwbnou , a4dh5skyzq ) ; gxfvl5ry4o =
bs2p213prd * bs2p213prd ; gxfvl5ry4o = localP -> P_6 * gxfvl5ry4o / ( localP
-> P_5 * gxfvl5ry4o + localB -> cdfywo5tmc ) + muDoubleScalarAtan2 (
a4dh5skyzq , h2ovgwbnou ) ; cxo4thuzp3 -> re = localP -> P_3 * bs2p213prd / (
bs2p213prd * bs2p213prd * localP -> P_2 + localB -> hpc1403dsj ) *
muDoubleScalarCos ( gxfvl5ry4o ) * localP -> P_7 ; cxo4thuzp3 -> im = localP
-> P_3 * bs2p213prd / ( bs2p213prd * bs2p213prd * localP -> P_2 + localB ->
hpc1403dsj ) * muDoubleScalarSin ( gxfvl5ry4o ) * localP -> P_7 ; } void
ehval41sziTID3 ( dctlrdbhva * localB , f0ewbxt5x2 * localP ) { localB ->
hpc1403dsj = localP -> P_0 ; localB -> cdfywo5tmc = localP -> P_4 ; } void
hyud5fc043 ( SimStruct * const S ) { } void azbbgayip0 ( creal_T ijm25csdjl ,
creal_T * jfxzz2dyq5 , lye2z2evhu * localB , dckodiwito * localP ) { real_T
of2ij23nzv ; real_T fgih4opxy5 ; real_T lrr4344f1y ; real_T g53pvykfqd ;
real_T cqm5n3ftcz ; g53pvykfqd = localP -> P_2 * ijm25csdjl . re ; cqm5n3ftcz
= localP -> P_2 * ijm25csdjl . im ; of2ij23nzv = muDoubleScalarHypot (
g53pvykfqd , cqm5n3ftcz ) ; fgih4opxy5 = muDoubleScalarPower ( of2ij23nzv ,
localB -> dcycvq4lkz ) ; lrr4344f1y = muDoubleScalarPower ( of2ij23nzv ,
localB -> dnrczyxq02 ) ; lrr4344f1y = ( localP -> P_9 * lrr4344f1y / ( localP
-> P_10 * lrr4344f1y + localB -> gtm0unwjd4 ) + localP -> P_8 * of2ij23nzv )
+ muDoubleScalarAtan2 ( cqm5n3ftcz , g53pvykfqd ) ; jfxzz2dyq5 -> re = (
localP -> P_4 * fgih4opxy5 / ( localP -> P_5 * fgih4opxy5 + localB ->
ktitavrh5o ) + localP -> P_3 * of2ij23nzv ) * muDoubleScalarCos ( lrr4344f1y
) * localP -> P_11 ; jfxzz2dyq5 -> im = ( localP -> P_4 * fgih4opxy5 / (
localP -> P_5 * fgih4opxy5 + localB -> ktitavrh5o ) + localP -> P_3 *
of2ij23nzv ) * muDoubleScalarSin ( lrr4344f1y ) * localP -> P_11 ; } void
azbbgayip0TID3 ( lye2z2evhu * localB , dckodiwito * localP ) { localB ->
ktitavrh5o = localP -> P_0 ; localB -> dcycvq4lkz = localP -> P_1 ; localB ->
dnrczyxq02 = localP -> P_6 ; localB -> gtm0unwjd4 = localP -> P_7 ; } void
gghxoj2y0z ( SimStruct * const S ) { } void dm45ptzaog ( creal_T a2n3bg4wky ,
creal_T * izjktlkmwi , phtcbexvvb * localB , fpi4j2c0ib * localP ) { real_T
bcxxrdk3c0 ; real_T ej2rpmvd0k ; real_T fzcwmvegyj ; real_T kgyje3trfe ;
fzcwmvegyj = localP -> P_0 * a2n3bg4wky . re ; kgyje3trfe = localP -> P_0 *
a2n3bg4wky . im ; ej2rpmvd0k = muDoubleScalarHypot ( fzcwmvegyj , kgyje3trfe
) ; bcxxrdk3c0 = ej2rpmvd0k / localB -> fs5kcz2ycf ; if ( ( bcxxrdk3c0 < 0.0
) && ( localB -> dhpqxvh3ln > muDoubleScalarFloor ( localB -> dhpqxvh3ln ) )
) { bcxxrdk3c0 = - muDoubleScalarPower ( - bcxxrdk3c0 , localB -> dhpqxvh3ln
) ; } else { bcxxrdk3c0 = muDoubleScalarPower ( bcxxrdk3c0 , localB ->
dhpqxvh3ln ) ; } bcxxrdk3c0 += localB -> pvs5t5ap3n ; fzcwmvegyj =
muDoubleScalarAtan2 ( kgyje3trfe , fzcwmvegyj ) ; if ( ( bcxxrdk3c0 < 0.0 )
&& ( localB -> expmznz4by > muDoubleScalarFloor ( localB -> expmznz4by ) ) )
{ bcxxrdk3c0 = - muDoubleScalarPower ( - bcxxrdk3c0 , localB -> expmznz4by )
; } else { bcxxrdk3c0 = muDoubleScalarPower ( bcxxrdk3c0 , localB ->
expmznz4by ) ; } izjktlkmwi -> re = ej2rpmvd0k / bcxxrdk3c0 *
muDoubleScalarCos ( fzcwmvegyj ) * localP -> P_5 ; izjktlkmwi -> im =
ej2rpmvd0k / bcxxrdk3c0 * muDoubleScalarSin ( fzcwmvegyj ) * localP -> P_5 ;
} void dm45ptzaogTID3 ( phtcbexvvb * localB , fpi4j2c0ib * localP ) { localB
-> fs5kcz2ycf = localP -> P_1 ; localB -> dhpqxvh3ln = localP -> P_2 ; localB
-> pvs5t5ap3n = localP -> P_3 ; localB -> expmznz4by = localP -> P_4 ; } void
cv3pq1ehv3 ( SimStruct * const S ) { } void RandSrcInitState_GZ ( const
uint32_T seed [ ] , uint32_T state [ ] , int32_T nChans ) { int32_T i ; for (
i = 0 ; i < nChans ; i ++ ) { state [ i << 1 ] = 362436069U ; state [ ( i <<
1 ) + 1 ] = seed [ i ] == 0U ? 521288629U : seed [ i ] ; } } void
RandSrcInitState_U_64 ( const uint32_T seed [ ] , real_T state [ ] , int32_T
nChans ) { int32_T i ; uint32_T j ; int32_T k ; int32_T n ; real_T d ; for (
i = 0 ; i < nChans ; i ++ ) { j = seed [ i ] != 0U ? seed [ i ] : 2147483648U
; state [ 35 * i + 34 ] = j ; for ( k = 0 ; k < 32 ; k ++ ) { d = 0.0 ; for (
n = 0 ; n < 53 ; n ++ ) { j ^= j << 13 ; j ^= j >> 17 ; j ^= j << 5 ; d = (
real_T ) ( ( int32_T ) ( j >> 19 ) & 1 ) + ( d + d ) ; } state [ 35 * i + k ]
= ldexp ( d , - 53 ) ; } state [ 35 * i + 32 ] = 0.0 ; state [ 35 * i + 33 ]
= 0.0 ; } } void RandSrc_GZ_Z ( creal_T y [ ] , const creal_T mean [ ] ,
int32_T meanLen , const real_T xstd [ ] , int32_T xstdLen , uint32_T state [
] , int32_T nChans , int32_T nSamps ) { int32_T i ; int32_T j ; real_T r ;
real_T x ; real_T s ; real_T y_p ; int32_T chan ; real_T std ; uint32_T icng
; uint32_T jsr ; int32_T samp ; real_T resultsVal [ 2 ] ; real_T mean_p [ 2 ]
; static const real_T vt [ 65 ] = { 0.340945 , 0.4573146 , 0.5397793 ,
0.6062427 , 0.6631691 , 0.7136975 , 0.7596125 , 0.8020356 , 0.8417227 ,
0.8792102 , 0.9148948 , 0.9490791 , 0.9820005 , 1.0138492 , 1.044781 ,
1.0749254 , 1.1043917 , 1.1332738 , 1.161653 , 1.189601 , 1.2171815 ,
1.2444516 , 1.2714635 , 1.298265 , 1.3249008 , 1.3514125 , 1.3778399 ,
1.4042211 , 1.4305929 , 1.4569915 , 1.4834527 , 1.5100122 , 1.5367061 ,
1.5635712 , 1.5906454 , 1.617968 , 1.6455802 , 1.6735255 , 1.7018503 ,
1.7306045 , 1.7598422 , 1.7896223 , 1.8200099 , 1.851077 , 1.8829044 ,
1.9155831 , 1.9492166 , 1.9839239 , 2.0198431 , 2.0571356 , 2.095993 ,
2.136645 , 2.1793713 , 2.2245175 , 2.2725186 , 2.3239338 , 2.3795008 ,
2.4402218 , 2.5075117 , 2.5834658 , 2.6713916 , 2.7769942 , 2.7769942 ,
2.7769942 , 2.7769942 } ; nSamps += nSamps ; for ( chan = 0 ; chan < nChans ;
chan ++ ) { std = xstd [ xstdLen > 1 ? chan : 0 ] ; icng = state [ chan << 1
] ; jsr = state [ ( chan << 1 ) + 1 ] ; mean_p [ 0U ] = mean [ meanLen > 1 ?
chan : 0 ] . re ; mean_p [ 1U ] = mean [ meanLen > 1 ? chan : 0 ] . im ; for
( samp = 0 ; samp < nSamps ; samp ++ ) { icng = 69069U * icng + 1234567U ;
jsr ^= jsr << 13 ; jsr ^= jsr >> 17 ; jsr ^= jsr << 5 ; i = ( int32_T ) (
icng + jsr ) ; j = ( i & 63 ) + 1 ; r = ( real_T ) i * 4.6566128730773926E-10
* vt [ j ] ; if ( ! ( muDoubleScalarAbs ( r ) <= vt [ j - 1 ] ) ) { x = (
muDoubleScalarAbs ( r ) - vt [ j - 1 ] ) / ( vt [ j ] - vt [ j - 1 ] ) ; icng
= 69069U * icng + 1234567U ; jsr ^= jsr << 13 ; jsr ^= jsr >> 17 ; jsr ^= jsr
<< 5 ; y_p = ( real_T ) ( int32_T ) ( icng + jsr ) * 2.328306436538696E-10 +
0.5 ; s = x + y_p ; if ( s > 1.301198 ) { r = r < 0.0 ? 0.4878992 * x -
0.4878992 : 0.4878992 - 0.4878992 * x ; } else { if ( ! ( s <= 0.9689279 ) )
{ x = 0.4878992 - 0.4878992 * x ; if ( y_p > 12.67706 - muDoubleScalarExp ( -
0.5 * x * x ) * 12.37586 ) { r = r < 0.0 ? - x : x ; } else { if ( ! (
muDoubleScalarExp ( - 0.5 * vt [ j ] * vt [ j ] ) + y_p * 0.01958303 / vt [ j
] <= muDoubleScalarExp ( - 0.5 * r * r ) ) ) { do { icng = 69069U * icng +
1234567U ; jsr ^= jsr << 13 ; jsr ^= jsr >> 17 ; jsr ^= jsr << 5 ; x =
muDoubleScalarLog ( ( real_T ) ( int32_T ) ( icng + jsr ) *
2.328306436538696E-10 + 0.5 ) / 2.776994 ; icng = 69069U * icng + 1234567U ;
jsr ^= jsr << 13 ; jsr ^= jsr >> 17 ; jsr ^= jsr << 5 ; } while (
muDoubleScalarLog ( ( real_T ) ( int32_T ) ( icng + jsr ) *
2.328306436538696E-10 + 0.5 ) * - 2.0 <= x * x ) ; r = r < 0.0 ? x - 2.776994
: 2.776994 - x ; } } } } } resultsVal [ samp & 1 ] = mean_p [ samp & 1 ] +
std * r ; if ( ( samp & 1 ) != 0 ) { y [ chan * ( nSamps >> 1 ) + ( samp >> 1
) ] . re = resultsVal [ 0U ] ; y [ chan * ( nSamps >> 1 ) + ( samp >> 1 ) ] .
im = resultsVal [ 1U ] ; } } state [ chan << 1 ] = icng ; state [ ( chan << 1
) + 1 ] = jsr ; } } void RandSrc_U_D ( real_T y [ ] , const real_T minVec [ ]
, int32_T minLen , const real_T maxVec [ ] , int32_T maxLen , real_T state [
] , int32_T nChans , int32_T nSamps ) { int32_T one ; int32_T lsw ; int8_T *
onePtr ; int32_T chan ; real_T min ; real_T max ; int32_T samps ; real_T d ;
int32_T i ; uint32_T j ; int32_T ii [ 2 ] ; one = 1 ; onePtr = ( int8_T * ) &
one ; lsw = ( onePtr [ 0U ] == 0 ) ; for ( chan = 0 ; chan < nChans ; chan ++
) { min = minVec [ minLen > 1 ? chan : 0 ] ; max = maxVec [ maxLen > 1 ? chan
: 0 ] ; max -= min ; i = ( int32_T ) ( ( uint32_T ) state [ chan * 35 + 33 ]
& 31U ) ; j = ( uint32_T ) state [ chan * 35 + 34 ] ; for ( samps = 0 ; samps
< nSamps ; samps ++ ) { d = state [ ( ( i + 20 ) & 31 ) + chan * 35 ] ; d -=
state [ ( ( i + 5 ) & 31 ) + chan * 35 ] ; d -= state [ chan * 35 + 32 ] ; if
( d >= 0.0 ) { state [ chan * 35 + 32 ] = 0.0 ; } else { d ++ ; state [ chan
* 35 + 32 ] = 1.1102230246251565E-16 ; } state [ chan * 35 + i ] = d ; i = (
i + 1 ) & 31 ; memcpy ( & ii [ 0U ] , & d , sizeof ( real_T ) ) ; ii [ lsw ]
^= j ; j ^= j << 13 ; j ^= j >> 17 ; j ^= j << 5 ; ii [ lsw ^ 1 ] ^= j &
1048575U ; memcpy ( & d , & ii [ 0U ] , sizeof ( real_T ) ) ; y [ chan *
nSamps + samps ] = max * d + min ; } state [ chan * 35 + 33 ] = i ; state [
chan * 35 + 34 ] = j ; } } static void mdlOutputs ( SimStruct * S , int_T tid
) { creal_T iybx40c3j2 ; creal_T nkeozlpthr ; creal_T ecemarztsa ; creal_T
oa4jxjurxe ; creal_T dxvedavi0p ; creal_T ecip225ogs ; creal_T as5idqbqii ;
creal_T ittjqgwjvi ; creal_T mk1ukspio1 ; creal_T eivbdys3ms ; creal_T
ihyohcotgn ; creal_T pftoavt13u ; creal_T irnd2cuy3r ; creal_T bn4w3fkd2a ;
creal_T bethmhicj2 ; creal_T fq5v3mf1du ; int32_T firstIteration ; int32_T
coefArrayIdx ; int32_T outBufIdx1 ; real_T nlkv1zr2pt ; real_T lezwklul0d ;
int32_T i ; int32_T tmp ; creal_T ay3510dv2g ; creal_T kdcznogb5j ; creal_T
l04hfnby22 ; creal_T iu1dnfe1l3 ; creal_T kwj5vskrts ; creal_T aktt2x2zs5 ;
creal_T kqk5d2qgsc ; creal_T d0vxsxil0p ; creal_T kdkx4p3v5r ; int32_T i_p ;
real_T accumulator_im ; kb33kd21op * _rtB ; cr0syazknf * _rtP ; j4fbbnriyn *
_rtDW ; _rtDW = ( ( j4fbbnriyn * ) ssGetRootDWork ( S ) ) ; _rtP = ( (
cr0syazknf * ) ssGetModelRtp ( S ) ) ; _rtB = ( ( kb33kd21op * )
_ssGetModelBlockIO ( S ) ) ; ssCallAccelRunBlock ( S , 55 , 0 ,
SS_CALL_MDL_OUTPUTS ) ; if ( ssIsSampleHit ( S , 1 , 0 ) ) { _rtB ->
az1daufoq1 = _rtDW -> npw4a00h3j ; } RandSrc_GZ_Z ( & ay3510dv2g , & _rtP ->
P_105 , 1 , & _rtP -> P_3 , 1 , _rtDW -> cilbx3vx24 , 1 , 1 ) ; nlkv1zr2pt =
_rtB -> a40tctgcb1 / _rtB -> jhqplovctz [ 0 ] * _rtP -> P_4 ; if ( nlkv1zr2pt
< 0.0 ) { nlkv1zr2pt = - muDoubleScalarSqrt ( muDoubleScalarAbs ( nlkv1zr2pt
) ) ; } else { nlkv1zr2pt = muDoubleScalarSqrt ( nlkv1zr2pt ) ; } iybx40c3j2
. re = ay3510dv2g . re * nlkv1zr2pt ; iybx40c3j2 . im = ay3510dv2g . im *
nlkv1zr2pt ; nlkv1zr2pt = _rtP -> P_5 * _rtB -> lum3ffjugx ; if (
ssIsSampleHit ( S , 1 , 0 ) ) { RandSrc_U_D ( & lezwklul0d , & _rtP -> P_6 ,
1 , & _rtP -> P_7 , 1 , _rtDW -> ajv21x2l1p , 1 , 1 ) ; lezwklul0d =
muDoubleScalarCeil ( lezwklul0d ) ; tmp = ( int32_T ) lezwklul0d ; _rtB ->
jahb5kusg5 . re = c4ffeboaz1 . dvbmkqfu5k [ tmp << 1 ] ; _rtB -> jahb5kusg5 .
im = c4ffeboaz1 . dvbmkqfu5k [ ( tmp << 1 ) + 1 ] ; if ( _rtDW -> bbg0ornexh
) { outBufIdx1 = 8 ; } else { outBufIdx1 = 0 ; } for ( i = 0 ; i < 8 ; i ++ )
{ firstIteration = outBufIdx1 + i ; coefArrayIdx = i * 11 ; for ( i_p = 1 ;
i_p - 1 < 1 ; i_p ++ ) { lezwklul0d = 0.0 ; accumulator_im = 0.0 ; for ( tmp
= 0 ; tmp < i_p ; tmp ++ ) { lezwklul0d += _rtP -> P_8 [ coefArrayIdx + tmp ]
* _rtB -> jahb5kusg5 . re ; accumulator_im += _rtP -> P_8 [ coefArrayIdx +
tmp ] * _rtB -> jahb5kusg5 . im ; } for ( tmp = 0 ; tmp < 11 - i_p ; tmp ++ )
{ lezwklul0d += _rtP -> P_8 [ ( coefArrayIdx + i_p ) + tmp ] * _rtDW ->
nrzekfed22 [ tmp ] . re ; accumulator_im += _rtP -> P_8 [ ( coefArrayIdx +
i_p ) + tmp ] * _rtDW -> nrzekfed22 [ tmp ] . im ; } _rtDW -> cisq4i1xul [
firstIteration ] . re = lezwklul0d ; _rtDW -> cisq4i1xul [ firstIteration ] .
im = accumulator_im ; firstIteration += 8 ; } } for ( i_p = 8 ; i_p >= 0 ;
i_p -- ) { _rtDW -> nrzekfed22 [ 1 + i_p ] = _rtDW -> nrzekfed22 [ i_p ] ; }
_rtDW -> nrzekfed22 [ 0 ] = _rtB -> jahb5kusg5 ; _rtDW -> bbg0ornexh = !
_rtDW -> bbg0ornexh ; } _rtB -> pdwflic5gb = _rtDW -> cisq4i1xul [ _rtDW ->
eg2jort0pr ] ; _rtDW -> eg2jort0pr ++ ; if ( _rtDW -> eg2jort0pr >= 16 ) {
_rtDW -> eg2jort0pr = 0 ; } ssCallAccelRunBlock ( S , 54 , 0 ,
SS_CALL_MDL_OUTPUTS ) ; _rtB -> i3ib1lwu4t . re = _rtP -> P_10 * _rtB ->
b1u1caukpu . re ; _rtB -> i3ib1lwu4t . im = _rtP -> P_10 * _rtB -> b1u1caukpu
. im ; RandSrc_GZ_Z ( & kdkx4p3v5r , & _rtP -> P_106 , 1 , & _rtP -> P_11 , 1
, _rtDW -> mzg215i5rt , 1 , 1 ) ; _rtDW -> oud3etdatl = muDoubleScalarSqrt (
_rtP -> P_13 / muDoubleScalarPower ( 10.0 , _rtP -> P_12 / 10.0 ) ) ; _rtB ->
p1pj3teqsb [ 0 ] . re = _rtDW -> oud3etdatl * kdkx4p3v5r . re ; _rtB ->
p1pj3teqsb [ 0 ] . im = _rtDW -> oud3etdatl * kdkx4p3v5r . im ; _rtB ->
p1pj3teqsb [ 0 ] . re += _rtB -> i3ib1lwu4t . re ; _rtB -> p1pj3teqsb [ 0 ] .
im += _rtB -> i3ib1lwu4t . im ; _rtB -> p1pj3teqsb [ 1 ] . re = _rtP -> P_14
* muDoubleScalarCos ( _rtDW -> b4ozfnppsa ) ; _rtB -> p1pj3teqsb [ 1 ] . im =
_rtP -> P_14 * muDoubleScalarSin ( _rtDW -> b4ozfnppsa ) ; _rtDW ->
b4ozfnppsa += _rtP -> P_15 * 5.4541818377503123E-7 ; if ( _rtDW -> b4ozfnppsa
>= 6.2831853071795862 ) { _rtDW -> b4ozfnppsa -= 6.2831853071795862 ; } else
{ if ( _rtDW -> b4ozfnppsa < 0.0 ) { _rtDW -> b4ozfnppsa +=
6.2831853071795862 ; } } ssCallAccelRunBlock ( S , 5 , 0 ,
SS_CALL_MDL_OUTPUTS ) ; if ( nlkv1zr2pt < 0.0 ) { nlkv1zr2pt =
muDoubleScalarCeil ( nlkv1zr2pt ) ; } else { nlkv1zr2pt = muDoubleScalarFloor
( nlkv1zr2pt ) ; } if ( muDoubleScalarIsNaN ( nlkv1zr2pt ) ||
muDoubleScalarIsInf ( nlkv1zr2pt ) ) { nlkv1zr2pt = 0.0 ; } else { nlkv1zr2pt
= muDoubleScalarRem ( nlkv1zr2pt , 4.294967296E+9 ) ; } switch ( nlkv1zr2pt <
0.0 ? - ( int32_T ) ( uint32_T ) - nlkv1zr2pt : ( int32_T ) ( uint32_T )
nlkv1zr2pt ) { case 0 : ke3md013gp ( _rtB -> dccorp1hsv [ 0 ] , & _rtB ->
lrdk2ig4pw , ( hfcskoczds * ) & _rtP -> ke3md013gpf ) ; break ; case 1 :
bgnxdoxzrs ( _rtB -> dccorp1hsv [ 0 ] , & _rtB -> lrdk2ig4pw , & _rtB ->
bgnxdoxzrso , ( mgpn43wxg5 * ) & _rtP -> bgnxdoxzrso ) ; break ; case 2 :
e1euhyqxus ( _rtB -> dccorp1hsv [ 0 ] , & _rtB -> lrdk2ig4pw , & _rtB ->
e1euhyqxusi , ( gk4zctqeq4 * ) & _rtP -> e1euhyqxusi ) ; break ; case 3 :
ehval41szi ( _rtB -> dccorp1hsv [ 0 ] , & _rtB -> lrdk2ig4pw , & _rtB ->
ehval41szii , ( f0ewbxt5x2 * ) & _rtP -> ehval41szii ) ; break ; case 4 :
azbbgayip0 ( _rtB -> dccorp1hsv [ 0 ] , & _rtB -> lrdk2ig4pw , & _rtB ->
azbbgayip0e , ( dckodiwito * ) & _rtP -> azbbgayip0e ) ; break ; case 5 :
dm45ptzaog ( _rtB -> dccorp1hsv [ 0 ] , & _rtB -> lrdk2ig4pw , & _rtB ->
dm45ptzaogh , ( fpi4j2c0ib * ) & _rtP -> dm45ptzaogh ) ; break ; } nkeozlpthr
= iybx40c3j2 ; nlkv1zr2pt = muDoubleScalarRound ( ( _rtB -> lrdk2ig4pw . re +
nkeozlpthr . re ) / _rtP -> P_19 ) * _rtP -> P_19 ; if ( nlkv1zr2pt > _rtP ->
P_20 ) { _rtB -> kubl2ytrp3 [ 0 ] . re = _rtP -> P_20 ; } else if (
nlkv1zr2pt < _rtP -> P_21 ) { _rtB -> kubl2ytrp3 [ 0 ] . re = _rtP -> P_21 ;
} else { _rtB -> kubl2ytrp3 [ 0 ] . re = nlkv1zr2pt ; } nlkv1zr2pt =
muDoubleScalarRound ( ( _rtB -> lrdk2ig4pw . im + nkeozlpthr . im ) / _rtP ->
P_22 ) * _rtP -> P_22 ; if ( nlkv1zr2pt > _rtP -> P_23 ) { _rtB -> kubl2ytrp3
[ 0 ] . im = _rtP -> P_23 ; } else if ( nlkv1zr2pt < _rtP -> P_24 ) { _rtB ->
kubl2ytrp3 [ 0 ] . im = _rtP -> P_24 ; } else { _rtB -> kubl2ytrp3 [ 0 ] . im
= nlkv1zr2pt ; } RandSrc_GZ_Z ( & kdcznogb5j , & _rtP -> P_107 , 1 , & _rtP
-> P_25 , 1 , _rtDW -> a4c5w1arfv , 1 , 1 ) ; nlkv1zr2pt = _rtB -> bwibxgeuz2
/ _rtB -> kxghoj153l [ 0 ] * _rtP -> P_26 ; if ( nlkv1zr2pt < 0.0 ) {
nlkv1zr2pt = - muDoubleScalarSqrt ( muDoubleScalarAbs ( nlkv1zr2pt ) ) ; }
else { nlkv1zr2pt = muDoubleScalarSqrt ( nlkv1zr2pt ) ; } ecemarztsa . re =
kdcznogb5j . re * nlkv1zr2pt ; ecemarztsa . im = kdcznogb5j . im * nlkv1zr2pt
; nlkv1zr2pt = _rtP -> P_27 * _rtB -> clisua33pj ; if ( nlkv1zr2pt < 0.0 ) {
nlkv1zr2pt = muDoubleScalarCeil ( nlkv1zr2pt ) ; } else { nlkv1zr2pt =
muDoubleScalarFloor ( nlkv1zr2pt ) ; } if ( muDoubleScalarIsNaN ( nlkv1zr2pt
) || muDoubleScalarIsInf ( nlkv1zr2pt ) ) { nlkv1zr2pt = 0.0 ; } else {
nlkv1zr2pt = muDoubleScalarRem ( nlkv1zr2pt , 4.294967296E+9 ) ; } switch (
nlkv1zr2pt < 0.0 ? - ( int32_T ) ( uint32_T ) - nlkv1zr2pt : ( int32_T ) (
uint32_T ) nlkv1zr2pt ) { case 0 : ke3md013gp ( _rtB -> dccorp1hsv [ 1 ] , &
_rtB -> a1zkdhap2f , ( hfcskoczds * ) & _rtP -> eysgxtzln4 ) ; break ; case 1
: bgnxdoxzrs ( _rtB -> dccorp1hsv [ 1 ] , & _rtB -> a1zkdhap2f , & _rtB ->
ldc0papvgx , ( mgpn43wxg5 * ) & _rtP -> ldc0papvgx ) ; break ; case 2 :
e1euhyqxus ( _rtB -> dccorp1hsv [ 1 ] , & _rtB -> a1zkdhap2f , & _rtB ->
ptytfvjmyf , ( gk4zctqeq4 * ) & _rtP -> ptytfvjmyf ) ; break ; case 3 :
ehval41szi ( _rtB -> dccorp1hsv [ 1 ] , & _rtB -> a1zkdhap2f , & _rtB ->
jv3cnfubul , ( f0ewbxt5x2 * ) & _rtP -> jv3cnfubul ) ; break ; case 4 :
azbbgayip0 ( _rtB -> dccorp1hsv [ 1 ] , & _rtB -> a1zkdhap2f , & _rtB ->
d42rppglcr , ( dckodiwito * ) & _rtP -> d42rppglcr ) ; break ; case 5 :
dm45ptzaog ( _rtB -> dccorp1hsv [ 1 ] , & _rtB -> a1zkdhap2f , & _rtB ->
gnvseqstkw , ( fpi4j2c0ib * ) & _rtP -> gnvseqstkw ) ; break ; } oa4jxjurxe =
ecemarztsa ; nlkv1zr2pt = muDoubleScalarRound ( ( _rtB -> a1zkdhap2f . re +
oa4jxjurxe . re ) / _rtP -> P_29 ) * _rtP -> P_29 ; if ( nlkv1zr2pt > _rtP ->
P_30 ) { _rtB -> kubl2ytrp3 [ 1 ] . re = _rtP -> P_30 ; } else if (
nlkv1zr2pt < _rtP -> P_31 ) { _rtB -> kubl2ytrp3 [ 1 ] . re = _rtP -> P_31 ;
} else { _rtB -> kubl2ytrp3 [ 1 ] . re = nlkv1zr2pt ; } nlkv1zr2pt =
muDoubleScalarRound ( ( _rtB -> a1zkdhap2f . im + oa4jxjurxe . im ) / _rtP ->
P_32 ) * _rtP -> P_32 ; if ( nlkv1zr2pt > _rtP -> P_33 ) { _rtB -> kubl2ytrp3
[ 1 ] . im = _rtP -> P_33 ; } else if ( nlkv1zr2pt < _rtP -> P_34 ) { _rtB ->
kubl2ytrp3 [ 1 ] . im = _rtP -> P_34 ; } else { _rtB -> kubl2ytrp3 [ 1 ] . im
= nlkv1zr2pt ; } RandSrc_GZ_Z ( & l04hfnby22 , & _rtP -> P_108 , 1 , & _rtP
-> P_35 , 1 , _rtDW -> ogxukxdqv1 , 1 , 1 ) ; nlkv1zr2pt = _rtB -> njgvvsoggz
/ _rtB -> fueogwfnma [ 0 ] * _rtP -> P_36 ; if ( nlkv1zr2pt < 0.0 ) {
nlkv1zr2pt = - muDoubleScalarSqrt ( muDoubleScalarAbs ( nlkv1zr2pt ) ) ; }
else { nlkv1zr2pt = muDoubleScalarSqrt ( nlkv1zr2pt ) ; } dxvedavi0p . re =
l04hfnby22 . re * nlkv1zr2pt ; dxvedavi0p . im = l04hfnby22 . im * nlkv1zr2pt
; nlkv1zr2pt = _rtP -> P_37 * _rtB -> f0dh52aqkk ; if ( nlkv1zr2pt < 0.0 ) {
nlkv1zr2pt = muDoubleScalarCeil ( nlkv1zr2pt ) ; } else { nlkv1zr2pt =
muDoubleScalarFloor ( nlkv1zr2pt ) ; } if ( muDoubleScalarIsNaN ( nlkv1zr2pt
) || muDoubleScalarIsInf ( nlkv1zr2pt ) ) { nlkv1zr2pt = 0.0 ; } else {
nlkv1zr2pt = muDoubleScalarRem ( nlkv1zr2pt , 4.294967296E+9 ) ; } switch (
nlkv1zr2pt < 0.0 ? - ( int32_T ) ( uint32_T ) - nlkv1zr2pt : ( int32_T ) (
uint32_T ) nlkv1zr2pt ) { case 0 : ke3md013gp ( _rtB -> dccorp1hsv [ 2 ] , &
_rtB -> edn5rgxifz , ( hfcskoczds * ) & _rtP -> o0lz1yta15 ) ; break ; case 1
: bgnxdoxzrs ( _rtB -> dccorp1hsv [ 2 ] , & _rtB -> edn5rgxifz , & _rtB ->
hxceaqj1j4 , ( mgpn43wxg5 * ) & _rtP -> hxceaqj1j4 ) ; break ; case 2 :
e1euhyqxus ( _rtB -> dccorp1hsv [ 2 ] , & _rtB -> edn5rgxifz , & _rtB ->
hkmt2lurcp , ( gk4zctqeq4 * ) & _rtP -> hkmt2lurcp ) ; break ; case 3 :
ehval41szi ( _rtB -> dccorp1hsv [ 2 ] , & _rtB -> edn5rgxifz , & _rtB ->
j0kqqyp53z , ( f0ewbxt5x2 * ) & _rtP -> j0kqqyp53z ) ; break ; case 4 :
azbbgayip0 ( _rtB -> dccorp1hsv [ 2 ] , & _rtB -> edn5rgxifz , & _rtB ->
btqoy2p2mc , ( dckodiwito * ) & _rtP -> btqoy2p2mc ) ; break ; case 5 :
dm45ptzaog ( _rtB -> dccorp1hsv [ 2 ] , & _rtB -> edn5rgxifz , & _rtB ->
kvximfh40t , ( fpi4j2c0ib * ) & _rtP -> kvximfh40t ) ; break ; } ecip225ogs =
dxvedavi0p ; nlkv1zr2pt = muDoubleScalarRound ( ( _rtB -> edn5rgxifz . re +
ecip225ogs . re ) / _rtP -> P_39 ) * _rtP -> P_39 ; if ( nlkv1zr2pt > _rtP ->
P_40 ) { _rtB -> kubl2ytrp3 [ 2 ] . re = _rtP -> P_40 ; } else if (
nlkv1zr2pt < _rtP -> P_41 ) { _rtB -> kubl2ytrp3 [ 2 ] . re = _rtP -> P_41 ;
} else { _rtB -> kubl2ytrp3 [ 2 ] . re = nlkv1zr2pt ; } nlkv1zr2pt =
muDoubleScalarRound ( ( _rtB -> edn5rgxifz . im + ecip225ogs . im ) / _rtP ->
P_42 ) * _rtP -> P_42 ; if ( nlkv1zr2pt > _rtP -> P_43 ) { _rtB -> kubl2ytrp3
[ 2 ] . im = _rtP -> P_43 ; } else if ( nlkv1zr2pt < _rtP -> P_44 ) { _rtB ->
kubl2ytrp3 [ 2 ] . im = _rtP -> P_44 ; } else { _rtB -> kubl2ytrp3 [ 2 ] . im
= nlkv1zr2pt ; } RandSrc_GZ_Z ( & iu1dnfe1l3 , & _rtP -> P_109 , 1 , & _rtP
-> P_45 , 1 , _rtDW -> d4n3n2cdul , 1 , 1 ) ; nlkv1zr2pt = _rtB -> oq5vpoqa1u
/ _rtB -> b20t3eqzmx [ 0 ] * _rtP -> P_46 ; if ( nlkv1zr2pt < 0.0 ) {
nlkv1zr2pt = - muDoubleScalarSqrt ( muDoubleScalarAbs ( nlkv1zr2pt ) ) ; }
else { nlkv1zr2pt = muDoubleScalarSqrt ( nlkv1zr2pt ) ; } as5idqbqii . re =
iu1dnfe1l3 . re * nlkv1zr2pt ; as5idqbqii . im = iu1dnfe1l3 . im * nlkv1zr2pt
; nlkv1zr2pt = _rtP -> P_47 * _rtB -> brf4wo51em ; if ( nlkv1zr2pt < 0.0 ) {
nlkv1zr2pt = muDoubleScalarCeil ( nlkv1zr2pt ) ; } else { nlkv1zr2pt =
muDoubleScalarFloor ( nlkv1zr2pt ) ; } if ( muDoubleScalarIsNaN ( nlkv1zr2pt
) || muDoubleScalarIsInf ( nlkv1zr2pt ) ) { nlkv1zr2pt = 0.0 ; } else {
nlkv1zr2pt = muDoubleScalarRem ( nlkv1zr2pt , 4.294967296E+9 ) ; } switch (
nlkv1zr2pt < 0.0 ? - ( int32_T ) ( uint32_T ) - nlkv1zr2pt : ( int32_T ) (
uint32_T ) nlkv1zr2pt ) { case 0 : ke3md013gp ( _rtB -> dccorp1hsv [ 3 ] , &
_rtB -> hhfmiydlnu , ( hfcskoczds * ) & _rtP -> ggy2cecwzd ) ; break ; case 1
: bgnxdoxzrs ( _rtB -> dccorp1hsv [ 3 ] , & _rtB -> hhfmiydlnu , & _rtB ->
jfilkpibyz , ( mgpn43wxg5 * ) & _rtP -> jfilkpibyz ) ; break ; case 2 :
e1euhyqxus ( _rtB -> dccorp1hsv [ 3 ] , & _rtB -> hhfmiydlnu , & _rtB ->
jf5pcxexaq , ( gk4zctqeq4 * ) & _rtP -> jf5pcxexaq ) ; break ; case 3 :
ehval41szi ( _rtB -> dccorp1hsv [ 3 ] , & _rtB -> hhfmiydlnu , & _rtB ->
fudhuw3f20 , ( f0ewbxt5x2 * ) & _rtP -> fudhuw3f20 ) ; break ; case 4 :
azbbgayip0 ( _rtB -> dccorp1hsv [ 3 ] , & _rtB -> hhfmiydlnu , & _rtB ->
cppnd2oryp , ( dckodiwito * ) & _rtP -> cppnd2oryp ) ; break ; case 5 :
dm45ptzaog ( _rtB -> dccorp1hsv [ 3 ] , & _rtB -> hhfmiydlnu , & _rtB ->
ewvjgp1nzs , ( fpi4j2c0ib * ) & _rtP -> ewvjgp1nzs ) ; break ; } ittjqgwjvi =
as5idqbqii ; nlkv1zr2pt = muDoubleScalarRound ( ( _rtB -> hhfmiydlnu . re +
ittjqgwjvi . re ) / _rtP -> P_49 ) * _rtP -> P_49 ; if ( nlkv1zr2pt > _rtP ->
P_50 ) { _rtB -> kubl2ytrp3 [ 3 ] . re = _rtP -> P_50 ; } else if (
nlkv1zr2pt < _rtP -> P_51 ) { _rtB -> kubl2ytrp3 [ 3 ] . re = _rtP -> P_51 ;
} else { _rtB -> kubl2ytrp3 [ 3 ] . re = nlkv1zr2pt ; } nlkv1zr2pt =
muDoubleScalarRound ( ( _rtB -> hhfmiydlnu . im + ittjqgwjvi . im ) / _rtP ->
P_52 ) * _rtP -> P_52 ; if ( nlkv1zr2pt > _rtP -> P_53 ) { _rtB -> kubl2ytrp3
[ 3 ] . im = _rtP -> P_53 ; } else if ( nlkv1zr2pt < _rtP -> P_54 ) { _rtB ->
kubl2ytrp3 [ 3 ] . im = _rtP -> P_54 ; } else { _rtB -> kubl2ytrp3 [ 3 ] . im
= nlkv1zr2pt ; } RandSrc_GZ_Z ( & kwj5vskrts , & _rtP -> P_110 , 1 , & _rtP
-> P_55 , 1 , _rtDW -> l5smgwi0v4 , 1 , 1 ) ; nlkv1zr2pt = _rtB -> eiaxjd5mbe
/ _rtB -> h4g4xdppfg [ 0 ] * _rtP -> P_56 ; if ( nlkv1zr2pt < 0.0 ) {
nlkv1zr2pt = - muDoubleScalarSqrt ( muDoubleScalarAbs ( nlkv1zr2pt ) ) ; }
else { nlkv1zr2pt = muDoubleScalarSqrt ( nlkv1zr2pt ) ; } mk1ukspio1 . re =
kwj5vskrts . re * nlkv1zr2pt ; mk1ukspio1 . im = kwj5vskrts . im * nlkv1zr2pt
; nlkv1zr2pt = _rtP -> P_57 * _rtB -> eut1pncnys ; if ( nlkv1zr2pt < 0.0 ) {
nlkv1zr2pt = muDoubleScalarCeil ( nlkv1zr2pt ) ; } else { nlkv1zr2pt =
muDoubleScalarFloor ( nlkv1zr2pt ) ; } if ( muDoubleScalarIsNaN ( nlkv1zr2pt
) || muDoubleScalarIsInf ( nlkv1zr2pt ) ) { nlkv1zr2pt = 0.0 ; } else {
nlkv1zr2pt = muDoubleScalarRem ( nlkv1zr2pt , 4.294967296E+9 ) ; } switch (
nlkv1zr2pt < 0.0 ? - ( int32_T ) ( uint32_T ) - nlkv1zr2pt : ( int32_T ) (
uint32_T ) nlkv1zr2pt ) { case 0 : ke3md013gp ( _rtB -> dccorp1hsv [ 4 ] , &
_rtB -> ildzfntkob , ( hfcskoczds * ) & _rtP -> ll55pbxqy4 ) ; break ; case 1
: bgnxdoxzrs ( _rtB -> dccorp1hsv [ 4 ] , & _rtB -> ildzfntkob , & _rtB ->
enhordppbg , ( mgpn43wxg5 * ) & _rtP -> enhordppbg ) ; break ; case 2 :
e1euhyqxus ( _rtB -> dccorp1hsv [ 4 ] , & _rtB -> ildzfntkob , & _rtB ->
m04d0vrz2a , ( gk4zctqeq4 * ) & _rtP -> m04d0vrz2a ) ; break ; case 3 :
ehval41szi ( _rtB -> dccorp1hsv [ 4 ] , & _rtB -> ildzfntkob , & _rtB ->
elrh2co23o , ( f0ewbxt5x2 * ) & _rtP -> elrh2co23o ) ; break ; case 4 :
azbbgayip0 ( _rtB -> dccorp1hsv [ 4 ] , & _rtB -> ildzfntkob , & _rtB ->
lj2evounis , ( dckodiwito * ) & _rtP -> lj2evounis ) ; break ; case 5 :
dm45ptzaog ( _rtB -> dccorp1hsv [ 4 ] , & _rtB -> ildzfntkob , & _rtB ->
hzgknpwv0s , ( fpi4j2c0ib * ) & _rtP -> hzgknpwv0s ) ; break ; } eivbdys3ms =
mk1ukspio1 ; nlkv1zr2pt = muDoubleScalarRound ( ( _rtB -> ildzfntkob . re +
eivbdys3ms . re ) / _rtP -> P_59 ) * _rtP -> P_59 ; if ( nlkv1zr2pt > _rtP ->
P_60 ) { _rtB -> kubl2ytrp3 [ 4 ] . re = _rtP -> P_60 ; } else if (
nlkv1zr2pt < _rtP -> P_61 ) { _rtB -> kubl2ytrp3 [ 4 ] . re = _rtP -> P_61 ;
} else { _rtB -> kubl2ytrp3 [ 4 ] . re = nlkv1zr2pt ; } nlkv1zr2pt =
muDoubleScalarRound ( ( _rtB -> ildzfntkob . im + eivbdys3ms . im ) / _rtP ->
P_62 ) * _rtP -> P_62 ; if ( nlkv1zr2pt > _rtP -> P_63 ) { _rtB -> kubl2ytrp3
[ 4 ] . im = _rtP -> P_63 ; } else if ( nlkv1zr2pt < _rtP -> P_64 ) { _rtB ->
kubl2ytrp3 [ 4 ] . im = _rtP -> P_64 ; } else { _rtB -> kubl2ytrp3 [ 4 ] . im
= nlkv1zr2pt ; } RandSrc_GZ_Z ( & aktt2x2zs5 , & _rtP -> P_111 , 1 , & _rtP
-> P_65 , 1 , _rtDW -> ivxkbodq3l , 1 , 1 ) ; nlkv1zr2pt = _rtB -> ejm1vosssz
/ _rtB -> mo3mwo4kby [ 0 ] * _rtP -> P_66 ; if ( nlkv1zr2pt < 0.0 ) {
nlkv1zr2pt = - muDoubleScalarSqrt ( muDoubleScalarAbs ( nlkv1zr2pt ) ) ; }
else { nlkv1zr2pt = muDoubleScalarSqrt ( nlkv1zr2pt ) ; } ihyohcotgn . re =
aktt2x2zs5 . re * nlkv1zr2pt ; ihyohcotgn . im = aktt2x2zs5 . im * nlkv1zr2pt
; nlkv1zr2pt = _rtP -> P_67 * _rtB -> hnkrqwwzep ; if ( nlkv1zr2pt < 0.0 ) {
nlkv1zr2pt = muDoubleScalarCeil ( nlkv1zr2pt ) ; } else { nlkv1zr2pt =
muDoubleScalarFloor ( nlkv1zr2pt ) ; } if ( muDoubleScalarIsNaN ( nlkv1zr2pt
) || muDoubleScalarIsInf ( nlkv1zr2pt ) ) { nlkv1zr2pt = 0.0 ; } else {
nlkv1zr2pt = muDoubleScalarRem ( nlkv1zr2pt , 4.294967296E+9 ) ; } switch (
nlkv1zr2pt < 0.0 ? - ( int32_T ) ( uint32_T ) - nlkv1zr2pt : ( int32_T ) (
uint32_T ) nlkv1zr2pt ) { case 0 : ke3md013gp ( _rtB -> dccorp1hsv [ 5 ] , &
_rtB -> bpth4jj3jo , ( hfcskoczds * ) & _rtP -> bwcnmwh5li ) ; break ; case 1
: bgnxdoxzrs ( _rtB -> dccorp1hsv [ 5 ] , & _rtB -> bpth4jj3jo , & _rtB ->
fn1p0l3god , ( mgpn43wxg5 * ) & _rtP -> fn1p0l3god ) ; break ; case 2 :
e1euhyqxus ( _rtB -> dccorp1hsv [ 5 ] , & _rtB -> bpth4jj3jo , & _rtB ->
p3ag23wbx2 , ( gk4zctqeq4 * ) & _rtP -> p3ag23wbx2 ) ; break ; case 3 :
ehval41szi ( _rtB -> dccorp1hsv [ 5 ] , & _rtB -> bpth4jj3jo , & _rtB ->
kflp23vorx , ( f0ewbxt5x2 * ) & _rtP -> kflp23vorx ) ; break ; case 4 :
azbbgayip0 ( _rtB -> dccorp1hsv [ 5 ] , & _rtB -> bpth4jj3jo , & _rtB ->
fpkrai54nt , ( dckodiwito * ) & _rtP -> fpkrai54nt ) ; break ; case 5 :
dm45ptzaog ( _rtB -> dccorp1hsv [ 5 ] , & _rtB -> bpth4jj3jo , & _rtB ->
oldceuyjbn , ( fpi4j2c0ib * ) & _rtP -> oldceuyjbn ) ; break ; } pftoavt13u =
ihyohcotgn ; nlkv1zr2pt = muDoubleScalarRound ( ( _rtB -> bpth4jj3jo . re +
pftoavt13u . re ) / _rtP -> P_69 ) * _rtP -> P_69 ; if ( nlkv1zr2pt > _rtP ->
P_70 ) { _rtB -> kubl2ytrp3 [ 5 ] . re = _rtP -> P_70 ; } else if (
nlkv1zr2pt < _rtP -> P_71 ) { _rtB -> kubl2ytrp3 [ 5 ] . re = _rtP -> P_71 ;
} else { _rtB -> kubl2ytrp3 [ 5 ] . re = nlkv1zr2pt ; } nlkv1zr2pt =
muDoubleScalarRound ( ( _rtB -> bpth4jj3jo . im + pftoavt13u . im ) / _rtP ->
P_72 ) * _rtP -> P_72 ; if ( nlkv1zr2pt > _rtP -> P_73 ) { _rtB -> kubl2ytrp3
[ 5 ] . im = _rtP -> P_73 ; } else if ( nlkv1zr2pt < _rtP -> P_74 ) { _rtB ->
kubl2ytrp3 [ 5 ] . im = _rtP -> P_74 ; } else { _rtB -> kubl2ytrp3 [ 5 ] . im
= nlkv1zr2pt ; } RandSrc_GZ_Z ( & kqk5d2qgsc , & _rtP -> P_112 , 1 , & _rtP
-> P_75 , 1 , _rtDW -> kfwnufufc2 , 1 , 1 ) ; nlkv1zr2pt = _rtB -> acekj4ssbf
/ _rtB -> iu1p23kdzq [ 0 ] * _rtP -> P_76 ; if ( nlkv1zr2pt < 0.0 ) {
nlkv1zr2pt = - muDoubleScalarSqrt ( muDoubleScalarAbs ( nlkv1zr2pt ) ) ; }
else { nlkv1zr2pt = muDoubleScalarSqrt ( nlkv1zr2pt ) ; } irnd2cuy3r . re =
kqk5d2qgsc . re * nlkv1zr2pt ; irnd2cuy3r . im = kqk5d2qgsc . im * nlkv1zr2pt
; nlkv1zr2pt = _rtP -> P_77 * _rtB -> bcb0pwpjwy ; if ( nlkv1zr2pt < 0.0 ) {
nlkv1zr2pt = muDoubleScalarCeil ( nlkv1zr2pt ) ; } else { nlkv1zr2pt =
muDoubleScalarFloor ( nlkv1zr2pt ) ; } if ( muDoubleScalarIsNaN ( nlkv1zr2pt
) || muDoubleScalarIsInf ( nlkv1zr2pt ) ) { nlkv1zr2pt = 0.0 ; } else {
nlkv1zr2pt = muDoubleScalarRem ( nlkv1zr2pt , 4.294967296E+9 ) ; } switch (
nlkv1zr2pt < 0.0 ? - ( int32_T ) ( uint32_T ) - nlkv1zr2pt : ( int32_T ) (
uint32_T ) nlkv1zr2pt ) { case 0 : ke3md013gp ( _rtB -> dccorp1hsv [ 6 ] , &
_rtB -> kn45wkf5og , ( hfcskoczds * ) & _rtP -> har3srfjuf ) ; break ; case 1
: bgnxdoxzrs ( _rtB -> dccorp1hsv [ 6 ] , & _rtB -> kn45wkf5og , & _rtB ->
pp24nkf1uv , ( mgpn43wxg5 * ) & _rtP -> pp24nkf1uv ) ; break ; case 2 :
e1euhyqxus ( _rtB -> dccorp1hsv [ 6 ] , & _rtB -> kn45wkf5og , & _rtB ->
ofbg4zsgr3 , ( gk4zctqeq4 * ) & _rtP -> ofbg4zsgr3 ) ; break ; case 3 :
ehval41szi ( _rtB -> dccorp1hsv [ 6 ] , & _rtB -> kn45wkf5og , & _rtB ->
nonwoibfph , ( f0ewbxt5x2 * ) & _rtP -> nonwoibfph ) ; break ; case 4 :
azbbgayip0 ( _rtB -> dccorp1hsv [ 6 ] , & _rtB -> kn45wkf5og , & _rtB ->
iecvxru0fq , ( dckodiwito * ) & _rtP -> iecvxru0fq ) ; break ; case 5 :
dm45ptzaog ( _rtB -> dccorp1hsv [ 6 ] , & _rtB -> kn45wkf5og , & _rtB ->
d4n1mndcab , ( fpi4j2c0ib * ) & _rtP -> d4n1mndcab ) ; break ; } bn4w3fkd2a =
irnd2cuy3r ; nlkv1zr2pt = muDoubleScalarRound ( ( _rtB -> kn45wkf5og . re +
bn4w3fkd2a . re ) / _rtP -> P_79 ) * _rtP -> P_79 ; if ( nlkv1zr2pt > _rtP ->
P_80 ) { _rtB -> kubl2ytrp3 [ 6 ] . re = _rtP -> P_80 ; } else if (
nlkv1zr2pt < _rtP -> P_81 ) { _rtB -> kubl2ytrp3 [ 6 ] . re = _rtP -> P_81 ;
} else { _rtB -> kubl2ytrp3 [ 6 ] . re = nlkv1zr2pt ; } nlkv1zr2pt =
muDoubleScalarRound ( ( _rtB -> kn45wkf5og . im + bn4w3fkd2a . im ) / _rtP ->
P_82 ) * _rtP -> P_82 ; if ( nlkv1zr2pt > _rtP -> P_83 ) { _rtB -> kubl2ytrp3
[ 6 ] . im = _rtP -> P_83 ; } else if ( nlkv1zr2pt < _rtP -> P_84 ) { _rtB ->
kubl2ytrp3 [ 6 ] . im = _rtP -> P_84 ; } else { _rtB -> kubl2ytrp3 [ 6 ] . im
= nlkv1zr2pt ; } RandSrc_GZ_Z ( & d0vxsxil0p , & _rtP -> P_113 , 1 , & _rtP
-> P_85 , 1 , _rtDW -> pg42bwzhxn , 1 , 1 ) ; nlkv1zr2pt = _rtB -> agrcxnxycq
/ _rtB -> bpf0icokmg [ 0 ] * _rtP -> P_86 ; if ( nlkv1zr2pt < 0.0 ) {
nlkv1zr2pt = - muDoubleScalarSqrt ( muDoubleScalarAbs ( nlkv1zr2pt ) ) ; }
else { nlkv1zr2pt = muDoubleScalarSqrt ( nlkv1zr2pt ) ; } bethmhicj2 . re =
d0vxsxil0p . re * nlkv1zr2pt ; bethmhicj2 . im = d0vxsxil0p . im * nlkv1zr2pt
; nlkv1zr2pt = _rtP -> P_87 * _rtB -> kdjaj0ms0o ; if ( nlkv1zr2pt < 0.0 ) {
nlkv1zr2pt = muDoubleScalarCeil ( nlkv1zr2pt ) ; } else { nlkv1zr2pt =
muDoubleScalarFloor ( nlkv1zr2pt ) ; } if ( muDoubleScalarIsNaN ( nlkv1zr2pt
) || muDoubleScalarIsInf ( nlkv1zr2pt ) ) { nlkv1zr2pt = 0.0 ; } else {
nlkv1zr2pt = muDoubleScalarRem ( nlkv1zr2pt , 4.294967296E+9 ) ; } switch (
nlkv1zr2pt < 0.0 ? - ( int32_T ) ( uint32_T ) - nlkv1zr2pt : ( int32_T ) (
uint32_T ) nlkv1zr2pt ) { case 0 : ke3md013gp ( _rtB -> dccorp1hsv [ 7 ] , &
_rtB -> d2erwmv0i0 , ( hfcskoczds * ) & _rtP -> mjapvf1lgb ) ; break ; case 1
: bgnxdoxzrs ( _rtB -> dccorp1hsv [ 7 ] , & _rtB -> d2erwmv0i0 , & _rtB ->
pqmmaxbcof , ( mgpn43wxg5 * ) & _rtP -> pqmmaxbcof ) ; break ; case 2 :
e1euhyqxus ( _rtB -> dccorp1hsv [ 7 ] , & _rtB -> d2erwmv0i0 , & _rtB ->
hz1mnqzl1y , ( gk4zctqeq4 * ) & _rtP -> hz1mnqzl1y ) ; break ; case 3 :
ehval41szi ( _rtB -> dccorp1hsv [ 7 ] , & _rtB -> d2erwmv0i0 , & _rtB ->
eggjh25mqq , ( f0ewbxt5x2 * ) & _rtP -> eggjh25mqq ) ; break ; case 4 :
azbbgayip0 ( _rtB -> dccorp1hsv [ 7 ] , & _rtB -> d2erwmv0i0 , & _rtB ->
cmk1zthcws , ( dckodiwito * ) & _rtP -> cmk1zthcws ) ; break ; case 5 :
dm45ptzaog ( _rtB -> dccorp1hsv [ 7 ] , & _rtB -> d2erwmv0i0 , & _rtB ->
jrktoyg454 , ( fpi4j2c0ib * ) & _rtP -> jrktoyg454 ) ; break ; } fq5v3mf1du =
bethmhicj2 ; nlkv1zr2pt = muDoubleScalarRound ( ( _rtB -> d2erwmv0i0 . re +
fq5v3mf1du . re ) / _rtP -> P_89 ) * _rtP -> P_89 ; if ( nlkv1zr2pt > _rtP ->
P_90 ) { _rtB -> kubl2ytrp3 [ 7 ] . re = _rtP -> P_90 ; } else if (
nlkv1zr2pt < _rtP -> P_91 ) { _rtB -> kubl2ytrp3 [ 7 ] . re = _rtP -> P_91 ;
} else { _rtB -> kubl2ytrp3 [ 7 ] . re = nlkv1zr2pt ; } nlkv1zr2pt =
muDoubleScalarRound ( ( _rtB -> d2erwmv0i0 . im + fq5v3mf1du . im ) / _rtP ->
P_92 ) * _rtP -> P_92 ; if ( nlkv1zr2pt > _rtP -> P_93 ) { _rtB -> kubl2ytrp3
[ 7 ] . im = _rtP -> P_93 ; } else if ( nlkv1zr2pt < _rtP -> P_94 ) { _rtB ->
kubl2ytrp3 [ 7 ] . im = _rtP -> P_94 ; } else { _rtB -> kubl2ytrp3 [ 7 ] . im
= nlkv1zr2pt ; } ssCallAccelRunBlock ( S , 2 , 0 , SS_CALL_MDL_OUTPUTS ) ;
_rtB -> dhwvy5gxjr [ 0 ] = _rtP -> P_95 * _rtB -> bsoeo44021 [ 0 ] + _rtP ->
P_96 ; _rtB -> dhwvy5gxjr [ 1 ] = _rtP -> P_95 * _rtB -> bsoeo44021 [ 1 ] +
_rtP -> P_96 ; ssCallAccelRunBlock ( S , 0 , 0 , SS_CALL_MDL_OUTPUTS ) ;
ssCallAccelRunBlock ( S , 55 , 212 , SS_CALL_MDL_OUTPUTS ) ; if (
ssIsSampleHit ( S , 1 , 0 ) ) { ssCallAccelRunBlock ( S , 55 , 213 ,
SS_CALL_MDL_OUTPUTS ) ; } ssCallAccelRunBlock ( S , 55 , 214 ,
SS_CALL_MDL_OUTPUTS ) ; ssCallAccelRunBlock ( S , 55 , 215 ,
SS_CALL_MDL_OUTPUTS ) ; outBufIdx1 = 1 ; tmp = 2048 - _rtDW -> ky4ifs53ge ;
firstIteration = _rtDW -> ky4ifs53ge ; if ( tmp <= 1 ) { i_p = 0 ; while (
i_p < tmp ) { _rtDW -> ke1lel2uwp [ _rtDW -> ky4ifs53ge ] = _rtB ->
i3ib1lwu4t ; i_p = 1 ; } firstIteration = 0 ; outBufIdx1 = 1 - tmp ; } for (
i_p = 0 ; i_p < outBufIdx1 ; i_p ++ ) { _rtDW -> ke1lel2uwp [ firstIteration
+ i_p ] = _rtB -> i3ib1lwu4t ; } _rtDW -> ky4ifs53ge ++ ; if ( _rtDW ->
ky4ifs53ge >= 2048 ) { _rtDW -> ky4ifs53ge -= 2048 ; } _rtDW -> bywjvaibji ++
; if ( _rtDW -> bywjvaibji > 2048 ) { _rtDW -> n50jq0yfqy = ( _rtDW ->
n50jq0yfqy + _rtDW -> bywjvaibji ) - 2048 ; if ( _rtDW -> n50jq0yfqy > 2048 )
{ _rtDW -> n50jq0yfqy -= 2048 ; } _rtDW -> bywjvaibji = 2048 ; } if (
ssIsSampleHit ( S , 2 , 0 ) ) { _rtDW -> bywjvaibji -= 1024 ; if ( _rtDW ->
bywjvaibji < 0 ) { _rtDW -> n50jq0yfqy += _rtDW -> bywjvaibji ; if ( _rtDW ->
n50jq0yfqy < 0 ) { _rtDW -> n50jq0yfqy += 2048 ; } _rtDW -> bywjvaibji = 0 ;
} firstIteration = 0 ; i = _rtDW -> n50jq0yfqy ; if ( _rtDW -> n50jq0yfqy < 0
) { i = _rtDW -> n50jq0yfqy + 2048 ; } tmp = 2048 - i ; outBufIdx1 = 1024 ;
if ( tmp <= 1024 ) { for ( i_p = 0 ; i_p < tmp ; i_p ++ ) { _rtB ->
jbsg1ejg2g [ i_p ] = _rtDW -> ke1lel2uwp [ i + i_p ] ; } firstIteration = tmp
; i = 0 ; outBufIdx1 = 1024 - tmp ; } for ( i_p = 0 ; i_p < outBufIdx1 ; i_p
++ ) { _rtB -> jbsg1ejg2g [ firstIteration + i_p ] = _rtDW -> ke1lel2uwp [ i
+ i_p ] ; } _rtDW -> n50jq0yfqy = i + outBufIdx1 ; for ( i_p = 0 ; i_p < 1024
; i_p ++ ) { _rtB -> de445ixhmn [ i_p ] = _rtB -> jbsg1ejg2g [ i_p ] . re *
_rtB -> jbsg1ejg2g [ i_p ] . re + _rtB -> jbsg1ejg2g [ i_p ] . im * _rtB ->
jbsg1ejg2g [ i_p ] . im ; } nlkv1zr2pt = _rtB -> de445ixhmn [ 0 ] ; for (
outBufIdx1 = 0 ; outBufIdx1 < 1023 ; outBufIdx1 ++ ) { nlkv1zr2pt += _rtB ->
de445ixhmn [ outBufIdx1 + 1 ] ; } nlkv1zr2pt = muDoubleScalarSqrt ( _rtP ->
P_98 * nlkv1zr2pt ) + _rtB -> kwkl05u4rb ; _rtB -> cyssqmxrk4 =
muDoubleScalarLog10 ( nlkv1zr2pt * nlkv1zr2pt * _rtP -> P_100 ) * _rtP ->
P_101 + _rtB -> proqedmpvh ; ssCallAccelRunBlock ( S , 55 , 229 ,
SS_CALL_MDL_OUTPUTS ) ; } ssCallAccelRunBlock ( S , 55 , 230 ,
SS_CALL_MDL_OUTPUTS ) ; if ( ssIsSampleHit ( S , 1 , 0 ) ) {
ssCallAccelRunBlock ( S , 55 , 231 , SS_CALL_MDL_OUTPUTS ) ; }
ssCallAccelRunBlock ( S , 1 , 0 , SS_CALL_MDL_OUTPUTS ) ; ssCallAccelRunBlock
( S , 3 , 0 , SS_CALL_MDL_OUTPUTS ) ; tmp = _rtDW -> khxayc1tps + 1 ; i_p =
_rtDW -> izlupvzqp4 ; outBufIdx1 = ( _rtDW -> khxayc1tps + 1 ) * 10 ; _rtDW
-> dqxp2oa23v . re += _rtB -> ppvwrgyjcz . re * _rtP -> P_103 [ _rtDW ->
jb0u5ndgbe ] ; _rtDW -> dqxp2oa23v . im += _rtB -> ppvwrgyjcz . im * _rtP ->
P_103 [ _rtDW -> jb0u5ndgbe ] ; i = _rtDW -> jb0u5ndgbe + 1 ; for (
firstIteration = _rtDW -> iwfmkc2wgp + 1 ; firstIteration < outBufIdx1 ;
firstIteration ++ ) { _rtDW -> dqxp2oa23v . re += _rtDW -> fe5jzumpym [
firstIteration ] . re * _rtP -> P_103 [ i ] ; _rtDW -> dqxp2oa23v . im +=
_rtDW -> fe5jzumpym [ firstIteration ] . im * _rtP -> P_103 [ i ] ; i ++ ; }
for ( firstIteration = outBufIdx1 - 10 ; firstIteration <= _rtDW ->
iwfmkc2wgp ; firstIteration ++ ) { _rtDW -> dqxp2oa23v . re += _rtDW ->
fe5jzumpym [ firstIteration ] . re * _rtP -> P_103 [ i ] ; _rtDW ->
dqxp2oa23v . im += _rtDW -> fe5jzumpym [ firstIteration ] . im * _rtP ->
P_103 [ i ] ; i ++ ; } _rtDW -> fe5jzumpym [ _rtDW -> iwfmkc2wgp ] = _rtB ->
ppvwrgyjcz ; outBufIdx1 = _rtDW -> iwfmkc2wgp + 10 ; if ( outBufIdx1 >= 80 )
{ outBufIdx1 -= 80 ; } if ( ! ( tmp < 8 ) ) { _rtDW -> l2ybm55bh4 = _rtDW ->
dqxp2oa23v ; i_p = _rtDW -> izlupvzqp4 + 1 ; _rtDW -> dqxp2oa23v . re = 0.0 ;
_rtDW -> dqxp2oa23v . im = 0.0 ; tmp = 0 ; i = 0 ; outBufIdx1 -- ; if (
outBufIdx1 < 0 ) { outBufIdx1 += 10 ; } } _rtDW -> iwfmkc2wgp = outBufIdx1 ;
_rtDW -> jb0u5ndgbe = i ; _rtDW -> khxayc1tps = tmp ; _rtDW -> izlupvzqp4 =
i_p ; if ( ssIsSpecialSampleHit ( S , 1 , 0 , 0 ) ) { _rtB -> fixquhx0if =
_rtDW -> l2ybm55bh4 ; _rtDW -> izlupvzqp4 = 0 ; } if ( ssIsSampleHit ( S , 1
, 0 ) ) { _rtB -> lsu1gd24h3 = _rtDW -> idktfijado [ 0 ] ;
ssCallAccelRunBlock ( S , 4 , 0 , SS_CALL_MDL_OUTPUTS ) ; } lezwklul0d = _rtB
-> kubl2ytrp3 [ 0 ] . re ; accumulator_im = _rtB -> kubl2ytrp3 [ 0 ] . im ;
for ( outBufIdx1 = 0 ; outBufIdx1 < 7 ; outBufIdx1 ++ ) { lezwklul0d += _rtB
-> kubl2ytrp3 [ outBufIdx1 + 1 ] . re ; accumulator_im += _rtB -> kubl2ytrp3
[ outBufIdx1 + 1 ] . im ; } _rtB -> p2qm2oyfl5 . re = lezwklul0d ; _rtB ->
p2qm2oyfl5 . im = accumulator_im ; UNUSED_PARAMETER ( tid ) ; } static void
mdlOutputsTID3 ( SimStruct * S , int_T tid ) { kb33kd21op * _rtB ; cr0syazknf
* _rtP ; _rtP = ( ( cr0syazknf * ) ssGetModelRtp ( S ) ) ; _rtB = ( (
kb33kd21op * ) _ssGetModelBlockIO ( S ) ) ; _rtB -> pdzd30yqtl [ 0 ] = _rtP
-> P_9 [ 0 ] ; _rtB -> pdzd30yqtl [ 1 ] = _rtP -> P_9 [ 1 ] ; _rtB ->
e24rkrvx5k [ 0 ] = _rtP -> P_17 [ 0 ] ; _rtB -> e24rkrvx5k [ 1 ] = _rtP ->
P_17 [ 1 ] ; _rtB -> e24rkrvx5k [ 2 ] = _rtP -> P_17 [ 2 ] ; _rtB ->
e24rkrvx5k [ 3 ] = _rtP -> P_17 [ 3 ] ; bgnxdoxzrsTID3 ( & _rtB ->
bgnxdoxzrso , ( mgpn43wxg5 * ) & _rtP -> bgnxdoxzrso ) ; e1euhyqxusTID3 ( &
_rtB -> e1euhyqxusi , ( gk4zctqeq4 * ) & _rtP -> e1euhyqxusi ) ;
ehval41sziTID3 ( & _rtB -> ehval41szii , ( f0ewbxt5x2 * ) & _rtP ->
ehval41szii ) ; azbbgayip0TID3 ( & _rtB -> azbbgayip0e , ( dckodiwito * ) &
_rtP -> azbbgayip0e ) ; dm45ptzaogTID3 ( & _rtB -> dm45ptzaogh , ( fpi4j2c0ib
* ) & _rtP -> dm45ptzaogh ) ; bgnxdoxzrsTID3 ( & _rtB -> ldc0papvgx , (
mgpn43wxg5 * ) & _rtP -> ldc0papvgx ) ; e1euhyqxusTID3 ( & _rtB -> ptytfvjmyf
, ( gk4zctqeq4 * ) & _rtP -> ptytfvjmyf ) ; ehval41sziTID3 ( & _rtB ->
jv3cnfubul , ( f0ewbxt5x2 * ) & _rtP -> jv3cnfubul ) ; azbbgayip0TID3 ( &
_rtB -> d42rppglcr , ( dckodiwito * ) & _rtP -> d42rppglcr ) ; dm45ptzaogTID3
( & _rtB -> gnvseqstkw , ( fpi4j2c0ib * ) & _rtP -> gnvseqstkw ) ;
bgnxdoxzrsTID3 ( & _rtB -> hxceaqj1j4 , ( mgpn43wxg5 * ) & _rtP -> hxceaqj1j4
) ; e1euhyqxusTID3 ( & _rtB -> hkmt2lurcp , ( gk4zctqeq4 * ) & _rtP ->
hkmt2lurcp ) ; ehval41sziTID3 ( & _rtB -> j0kqqyp53z , ( f0ewbxt5x2 * ) &
_rtP -> j0kqqyp53z ) ; azbbgayip0TID3 ( & _rtB -> btqoy2p2mc , ( dckodiwito *
) & _rtP -> btqoy2p2mc ) ; dm45ptzaogTID3 ( & _rtB -> kvximfh40t , (
fpi4j2c0ib * ) & _rtP -> kvximfh40t ) ; bgnxdoxzrsTID3 ( & _rtB -> jfilkpibyz
, ( mgpn43wxg5 * ) & _rtP -> jfilkpibyz ) ; e1euhyqxusTID3 ( & _rtB ->
jf5pcxexaq , ( gk4zctqeq4 * ) & _rtP -> jf5pcxexaq ) ; ehval41sziTID3 ( &
_rtB -> fudhuw3f20 , ( f0ewbxt5x2 * ) & _rtP -> fudhuw3f20 ) ; azbbgayip0TID3
( & _rtB -> cppnd2oryp , ( dckodiwito * ) & _rtP -> cppnd2oryp ) ;
dm45ptzaogTID3 ( & _rtB -> ewvjgp1nzs , ( fpi4j2c0ib * ) & _rtP -> ewvjgp1nzs
) ; bgnxdoxzrsTID3 ( & _rtB -> enhordppbg , ( mgpn43wxg5 * ) & _rtP ->
enhordppbg ) ; e1euhyqxusTID3 ( & _rtB -> m04d0vrz2a , ( gk4zctqeq4 * ) &
_rtP -> m04d0vrz2a ) ; ehval41sziTID3 ( & _rtB -> elrh2co23o , ( f0ewbxt5x2 *
) & _rtP -> elrh2co23o ) ; azbbgayip0TID3 ( & _rtB -> lj2evounis , (
dckodiwito * ) & _rtP -> lj2evounis ) ; dm45ptzaogTID3 ( & _rtB -> hzgknpwv0s
, ( fpi4j2c0ib * ) & _rtP -> hzgknpwv0s ) ; bgnxdoxzrsTID3 ( & _rtB ->
fn1p0l3god , ( mgpn43wxg5 * ) & _rtP -> fn1p0l3god ) ; e1euhyqxusTID3 ( &
_rtB -> p3ag23wbx2 , ( gk4zctqeq4 * ) & _rtP -> p3ag23wbx2 ) ; ehval41sziTID3
( & _rtB -> kflp23vorx , ( f0ewbxt5x2 * ) & _rtP -> kflp23vorx ) ;
azbbgayip0TID3 ( & _rtB -> fpkrai54nt , ( dckodiwito * ) & _rtP -> fpkrai54nt
) ; dm45ptzaogTID3 ( & _rtB -> oldceuyjbn , ( fpi4j2c0ib * ) & _rtP ->
oldceuyjbn ) ; bgnxdoxzrsTID3 ( & _rtB -> pp24nkf1uv , ( mgpn43wxg5 * ) &
_rtP -> pp24nkf1uv ) ; e1euhyqxusTID3 ( & _rtB -> ofbg4zsgr3 , ( gk4zctqeq4 *
) & _rtP -> ofbg4zsgr3 ) ; ehval41sziTID3 ( & _rtB -> nonwoibfph , (
f0ewbxt5x2 * ) & _rtP -> nonwoibfph ) ; azbbgayip0TID3 ( & _rtB -> iecvxru0fq
, ( dckodiwito * ) & _rtP -> iecvxru0fq ) ; dm45ptzaogTID3 ( & _rtB ->
d4n1mndcab , ( fpi4j2c0ib * ) & _rtP -> d4n1mndcab ) ; bgnxdoxzrsTID3 ( &
_rtB -> pqmmaxbcof , ( mgpn43wxg5 * ) & _rtP -> pqmmaxbcof ) ; e1euhyqxusTID3
( & _rtB -> hz1mnqzl1y , ( gk4zctqeq4 * ) & _rtP -> hz1mnqzl1y ) ;
ehval41sziTID3 ( & _rtB -> eggjh25mqq , ( f0ewbxt5x2 * ) & _rtP -> eggjh25mqq
) ; azbbgayip0TID3 ( & _rtB -> cmk1zthcws , ( dckodiwito * ) & _rtP ->
cmk1zthcws ) ; dm45ptzaogTID3 ( & _rtB -> jrktoyg454 , ( fpi4j2c0ib * ) &
_rtP -> jrktoyg454 ) ; _rtB -> kwkl05u4rb = _rtP -> P_99 ; _rtB -> proqedmpvh
= _rtP -> P_102 ; UNUSED_PARAMETER ( tid ) ; }
#define MDL_UPDATE
static void mdlUpdate ( SimStruct * S , int_T tid ) { int32_T idxDelay ;
kb33kd21op * _rtB ; j4fbbnriyn * _rtDW ; _rtDW = ( ( j4fbbnriyn * )
ssGetRootDWork ( S ) ) ; _rtB = ( ( kb33kd21op * ) _ssGetModelBlockIO ( S ) )
; ssCallAccelRunBlock ( S , 55 , 0 , SS_CALL_MDL_UPDATE ) ; if (
ssIsSampleHit ( S , 1 , 0 ) ) { _rtDW -> npw4a00h3j = _rtB -> e5lhwvazrj ;
ssCallAccelRunBlock ( S , 55 , 213 , SS_CALL_MDL_UPDATE ) ; }
ssCallAccelRunBlock ( S , 55 , 214 , SS_CALL_MDL_UPDATE ) ;
ssCallAccelRunBlock ( S , 55 , 215 , SS_CALL_MDL_UPDATE ) ; if (
ssIsSampleHit ( S , 1 , 0 ) ) { for ( idxDelay = 0 ; idxDelay < 9 ; idxDelay
++ ) { _rtDW -> idktfijado [ ( uint32_T ) idxDelay ] = _rtDW -> idktfijado [
idxDelay + 1U ] ; } _rtDW -> idktfijado [ 9 ] = _rtB -> jahb5kusg5 ; }
UNUSED_PARAMETER ( tid ) ; }
#define MDL_UPDATE
static void mdlUpdateTID3 ( SimStruct * S , int_T tid ) { UNUSED_PARAMETER (
tid ) ; } static void mdlInitializeSizes ( SimStruct * S ) { ssSetChecksumVal
( S , 0 , 411027465U ) ; ssSetChecksumVal ( S , 1 , 3415792553U ) ;
ssSetChecksumVal ( S , 2 , 2473959339U ) ; ssSetChecksumVal ( S , 3 ,
4039303526U ) ; { mxArray * slVerStructMat = NULL ; mxArray * slStrMat =
mxCreateString ( "simulink" ) ; char slVerChar [ 10 ] ; int status =
mexCallMATLAB ( 1 , & slVerStructMat , 1 , & slStrMat , "ver" ) ; if ( status
== 0 ) { mxArray * slVerMat = mxGetField ( slVerStructMat , 0 , "Version" ) ;
if ( slVerMat == NULL ) { status = 1 ; } else { status = mxGetString (
slVerMat , slVerChar , 10 ) ; } } mxDestroyArray ( slStrMat ) ;
mxDestroyArray ( slVerStructMat ) ; if ( ( status == 1 ) || ( strcmp (
slVerChar , "8.7" ) != 0 ) ) { return ; } } ssSetOptions ( S ,
SS_OPTION_EXCEPTION_FREE_CODE ) ; if ( ssGetSizeofDWork ( S ) != sizeof (
j4fbbnriyn ) ) { ssSetErrorStatus ( S ,
"Unexpected error: Internal DWork sizes do "
"not match for accelerator mex file." ) ; } if ( ssGetSizeofGlobalBlockIO ( S
) != sizeof ( kb33kd21op ) ) { ssSetErrorStatus ( S ,
"Unexpected error: Internal BlockIO sizes do "
"not match for accelerator mex file." ) ; } { int ssSizeofParams ;
ssGetSizeofParams ( S , & ssSizeofParams ) ; if ( ssSizeofParams != sizeof (
cr0syazknf ) ) { static char msg [ 256 ] ; sprintf ( msg ,
"Unexpected error: Internal Parameters sizes do "
"not match for accelerator mex file." ) ; } } _ssSetModelRtp ( S , ( real_T *
) & gr03u5oqod ) ; rt_InitInfAndNaN ( sizeof ( real_T ) ) ; ( ( cr0syazknf *
) ssGetModelRtp ( S ) ) -> hz1mnqzl1y . P_6 = rtInf ; ( ( cr0syazknf * )
ssGetModelRtp ( S ) ) -> pqmmaxbcof . P_10 = rtInf ; ( ( cr0syazknf * )
ssGetModelRtp ( S ) ) -> ofbg4zsgr3 . P_6 = rtInf ; ( ( cr0syazknf * )
ssGetModelRtp ( S ) ) -> pp24nkf1uv . P_10 = rtInf ; ( ( cr0syazknf * )
ssGetModelRtp ( S ) ) -> p3ag23wbx2 . P_6 = rtInf ; ( ( cr0syazknf * )
ssGetModelRtp ( S ) ) -> fn1p0l3god . P_10 = rtInf ; ( ( cr0syazknf * )
ssGetModelRtp ( S ) ) -> m04d0vrz2a . P_6 = rtInf ; ( ( cr0syazknf * )
ssGetModelRtp ( S ) ) -> enhordppbg . P_10 = rtInf ; ( ( cr0syazknf * )
ssGetModelRtp ( S ) ) -> jf5pcxexaq . P_6 = rtInf ; ( ( cr0syazknf * )
ssGetModelRtp ( S ) ) -> jfilkpibyz . P_10 = rtInf ; ( ( cr0syazknf * )
ssGetModelRtp ( S ) ) -> hkmt2lurcp . P_6 = rtInf ; ( ( cr0syazknf * )
ssGetModelRtp ( S ) ) -> hxceaqj1j4 . P_10 = rtInf ; ( ( cr0syazknf * )
ssGetModelRtp ( S ) ) -> ptytfvjmyf . P_6 = rtInf ; ( ( cr0syazknf * )
ssGetModelRtp ( S ) ) -> ldc0papvgx . P_10 = rtInf ; ( ( cr0syazknf * )
ssGetModelRtp ( S ) ) -> e1euhyqxusi . P_6 = rtInf ; ( ( cr0syazknf * )
ssGetModelRtp ( S ) ) -> bgnxdoxzrso . P_10 = rtInf ; } static void
mdlInitializeSampleTimes ( SimStruct * S ) { { SimStruct * childS ;
SysOutputFcn * callSysFcns ; childS = ssGetSFunction ( S , 0 ) ; callSysFcns
= ssGetCallSystemOutputFcnList ( childS ) ; callSysFcns [ 3 + 0 ] = (
SysOutputFcn ) ( NULL ) ; } slAccRegPrmChangeFcn ( S , mdlOutputsTID3 ) ; }
static void mdlTerminate ( SimStruct * S ) { }
#include "simulink.c"
