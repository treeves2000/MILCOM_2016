#include "__cf_MIMOCommunicationsSystem.h"
#ifndef RTW_HEADER_MIMOCommunicationsSystem_acc_private_h_
#define RTW_HEADER_MIMOCommunicationsSystem_acc_private_h_
#include "rtwtypes.h"
#include "multiword_types.h"
#include "MIMOCommunicationsSystem_acc.h"
#if !defined(ss_VALIDATE_MEMORY)
#define ss_VALIDATE_MEMORY(S, ptr)   if(!(ptr)) {\
  ssSetErrorStatus(S, RT_MEMORY_ALLOCATION_ERROR);\
  }
#endif
#if !defined(rt_FREE)
#if !defined(_WIN32)
#define rt_FREE(ptr)   if((ptr) != (NULL)) {\
  free((ptr));\
  (ptr) = (NULL);\
  }
#else
#define rt_FREE(ptr)   if((ptr) != (NULL)) {\
  free((void *)(ptr));\
  (ptr) = (NULL);\
  }
#endif
#endif
#include "dsp_rt.h"
extern void RandSrcInitState_GZ ( const uint32_T seed [ ] , uint32_T state [
] , int32_T nChans ) ; extern void RandSrcInitState_U_64 ( const uint32_T
seed [ ] , real_T state [ ] , int32_T nChans ) ; extern void RandSrc_GZ_Z (
creal_T y [ ] , const creal_T mean [ ] , int32_T meanLen , const real_T xstd
[ ] , int32_T xstdLen , uint32_T state [ ] , int32_T nChans , int32_T nSamps
) ; extern void RandSrc_U_D ( real_T y [ ] , const real_T minVec [ ] ,
int32_T minLen , const real_T maxVec [ ] , int32_T maxLen , real_T state [ ]
, int32_T nChans , int32_T nSamps ) ; void ke3md013gp ( creal_T ocxhfu3ubv ,
creal_T * mst31g0w1q , hfcskoczds * localP ) ; void bgnxdoxzrs ( creal_T
pw4lzlzi22 , creal_T * agqgbjhu0x , d3vabf3din * localB , mgpn43wxg5 * localP
) ; void bgnxdoxzrsTID3 ( d3vabf3din * localB , mgpn43wxg5 * localP ) ; void
e1euhyqxus ( creal_T flnjiif2vq , creal_T * lnap4crgom , jr2jrb1kva * localB
, gk4zctqeq4 * localP ) ; void e1euhyqxusTID3 ( jr2jrb1kva * localB ,
gk4zctqeq4 * localP ) ; void ehval41szi ( creal_T fi2bbpc1fs , creal_T *
cxo4thuzp3 , dctlrdbhva * localB , f0ewbxt5x2 * localP ) ; void
ehval41sziTID3 ( dctlrdbhva * localB , f0ewbxt5x2 * localP ) ; void
azbbgayip0 ( creal_T ijm25csdjl , creal_T * jfxzz2dyq5 , lye2z2evhu * localB
, dckodiwito * localP ) ; void azbbgayip0TID3 ( lye2z2evhu * localB ,
dckodiwito * localP ) ; void dm45ptzaog ( creal_T a2n3bg4wky , creal_T *
izjktlkmwi , phtcbexvvb * localB , fpi4j2c0ib * localP ) ; void
dm45ptzaogTID3 ( phtcbexvvb * localB , fpi4j2c0ib * localP ) ;
#endif
