#include "__cf_MIMOCommunicationsSystem.h"
#ifndef RTW_HEADER_MIMOCommunicationsSystem_acc_types_h_
#define RTW_HEADER_MIMOCommunicationsSystem_acc_types_h_
#include "rtwtypes.h"
#include "multiword_types.h"
typedef struct hfcskoczds_ hfcskoczds ; typedef struct mgpn43wxg5_ mgpn43wxg5
; typedef struct gk4zctqeq4_ gk4zctqeq4 ; typedef struct f0ewbxt5x2_
f0ewbxt5x2 ; typedef struct dckodiwito_ dckodiwito ; typedef struct
fpi4j2c0ib_ fpi4j2c0ib ; typedef struct cr0syazknf_ cr0syazknf ;
#endif
