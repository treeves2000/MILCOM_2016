#include "__cf_MIMOCommunicationsSystem.h"
#ifndef RTW_HEADER_MIMOCommunicationsSystem_acc_h_
#define RTW_HEADER_MIMOCommunicationsSystem_acc_h_
#include <stddef.h>
#include <math.h>
#include <string.h>
#ifndef MIMOCommunicationsSystem_acc_COMMON_INCLUDES_
#define MIMOCommunicationsSystem_acc_COMMON_INCLUDES_
#include <stdlib.h>
#define S_FUNCTION_NAME simulink_only_sfcn 
#define S_FUNCTION_LEVEL 2
#define RTW_GENERATED_S_FUNCTION
#include "rtwtypes.h"
#include "simstruc.h"
#include "fixedpoint.h"
#endif
#include "MIMOCommunicationsSystem_acc_types.h"
#include "multiword_types.h"
#include "mwmathutil.h"
#include "rtGetInf.h"
#include "rt_defines.h"
#include "rt_nonfinite.h"
typedef struct { int8_T dvua3dlxzf ; char_T cqarwf5o4s [ 7 ] ; } iupcmfgd0d ;
typedef struct { real_T hycoygaup5 ; real_T gopabpt5xb ; real_T djbeaaxtif ;
} d3vabf3din ; typedef struct { int8_T nrnx0trxoi ; char_T czcrg4z2a5 [ 7 ] ;
} i55gxqlq5v ; typedef struct { real_T oi1bn1f5os ; real_T baal5cg1qy ; }
jr2jrb1kva ; typedef struct { int8_T b0cgyolanq ; char_T bmdqli3vgo [ 7 ] ; }
dfrs4csji4 ; typedef struct { real_T hpc1403dsj ; real_T cdfywo5tmc ; }
dctlrdbhva ; typedef struct { int8_T inmtjsgayr ; char_T hgfkvoem2n [ 7 ] ; }
fdttpjehtz ; typedef struct { real_T ktitavrh5o ; real_T dcycvq4lkz ; real_T
dnrczyxq02 ; real_T gtm0unwjd4 ; } lye2z2evhu ; typedef struct { int8_T
jps5exh3wn ; char_T nxjeik1h2a [ 7 ] ; } aew4ycrzmw ; typedef struct { real_T
fs5kcz2ycf ; real_T dhpqxvh3ln ; real_T pvs5t5ap3n ; real_T expmznz4by ; }
phtcbexvvb ; typedef struct { int8_T frkz0duzbc ; char_T jtqspvd0cp [ 7 ] ; }
nfxat0gzy0 ; typedef struct { creal_T jahb5kusg5 ; creal_T pdwflic5gb ;
creal_T i3ib1lwu4t ; creal_T p1pj3teqsb [ 2 ] ; creal_T lrdk2ig4pw ; creal_T
a1zkdhap2f ; creal_T edn5rgxifz ; creal_T hhfmiydlnu ; creal_T ildzfntkob ;
creal_T bpth4jj3jo ; creal_T kn45wkf5og ; creal_T d2erwmv0i0 ; creal_T
kubl2ytrp3 [ 8 ] ; creal_T fixquhx0if ; creal_T lsu1gd24h3 ; creal_T
p2qm2oyfl5 ; creal_T b1u1caukpu ; creal_T dccorp1hsv [ 8 ] ; creal_T
ppvwrgyjcz ; creal_T gdpjvm3a4o ; creal_T jbsg1ejg2g [ 1024 ] ; real_T
az1daufoq1 ; real_T a40tctgcb1 ; real_T jhqplovctz [ 2 ] ; real_T lum3ffjugx
; real_T pdzd30yqtl [ 2 ] ; real_T e24rkrvx5k [ 4 ] ; real_T bwibxgeuz2 ;
real_T kxghoj153l [ 2 ] ; real_T clisua33pj ; real_T njgvvsoggz ; real_T
fueogwfnma [ 2 ] ; real_T f0dh52aqkk ; real_T oq5vpoqa1u ; real_T b20t3eqzmx
[ 2 ] ; real_T brf4wo51em ; real_T eiaxjd5mbe ; real_T h4g4xdppfg [ 2 ] ;
real_T eut1pncnys ; real_T ejm1vosssz ; real_T mo3mwo4kby [ 2 ] ; real_T
hnkrqwwzep ; real_T acekj4ssbf ; real_T iu1p23kdzq [ 2 ] ; real_T bcb0pwpjwy
; real_T agrcxnxycq ; real_T bpf0icokmg [ 2 ] ; real_T kdjaj0ms0o ; real_T
dhwvy5gxjr [ 2 ] ; real_T kwkl05u4rb ; real_T proqedmpvh ; real_T cyssqmxrk4
; real_T e5lhwvazrj ; real_T bsoeo44021 [ 2 ] ; real_T h2m5atjcaj [ 2 ] ;
real_T de445ixhmn [ 1024 ] ; phtcbexvvb jrktoyg454 ; lye2z2evhu cmk1zthcws ;
dctlrdbhva eggjh25mqq ; jr2jrb1kva hz1mnqzl1y ; d3vabf3din pqmmaxbcof ;
phtcbexvvb d4n1mndcab ; lye2z2evhu iecvxru0fq ; dctlrdbhva nonwoibfph ;
jr2jrb1kva ofbg4zsgr3 ; d3vabf3din pp24nkf1uv ; phtcbexvvb oldceuyjbn ;
lye2z2evhu fpkrai54nt ; dctlrdbhva kflp23vorx ; jr2jrb1kva p3ag23wbx2 ;
d3vabf3din fn1p0l3god ; phtcbexvvb hzgknpwv0s ; lye2z2evhu lj2evounis ;
dctlrdbhva elrh2co23o ; jr2jrb1kva m04d0vrz2a ; d3vabf3din enhordppbg ;
phtcbexvvb ewvjgp1nzs ; lye2z2evhu cppnd2oryp ; dctlrdbhva fudhuw3f20 ;
jr2jrb1kva jf5pcxexaq ; d3vabf3din jfilkpibyz ; phtcbexvvb kvximfh40t ;
lye2z2evhu btqoy2p2mc ; dctlrdbhva j0kqqyp53z ; jr2jrb1kva hkmt2lurcp ;
d3vabf3din hxceaqj1j4 ; phtcbexvvb gnvseqstkw ; lye2z2evhu d42rppglcr ;
dctlrdbhva jv3cnfubul ; jr2jrb1kva ptytfvjmyf ; d3vabf3din ldc0papvgx ;
phtcbexvvb dm45ptzaogh ; lye2z2evhu azbbgayip0e ; dctlrdbhva ehval41szii ;
jr2jrb1kva e1euhyqxusi ; d3vabf3din bgnxdoxzrso ; } kb33kd21op ; typedef
struct { creal_T nrzekfed22 [ 10 ] ; creal_T ke1lel2uwp [ 2048 ] ; creal_T
dqxp2oa23v ; creal_T fe5jzumpym [ 80 ] ; creal_T l2ybm55bh4 ; creal_T
idktfijado [ 10 ] ; real_T npw4a00h3j ; real_T b4ozfnppsa ; real_T douv41flhn
; creal_T cisq4i1xul [ 16 ] ; real_T ajv21x2l1p [ 35 ] ; real_T oud3etdatl ;
void * c4inaxpskx ; void * d3we5zb4sp ; void * kjoa4dkkms ; void * pek0r0mcvo
; void * hjatvwau1h ; void * dt1ww1oehw ; int32_T ky4ifs53ge ; int32_T
n50jq0yfqy ; int32_T bywjvaibji ; int32_T khxayc1tps ; int32_T jb0u5ndgbe ;
int32_T iwfmkc2wgp ; int32_T izlupvzqp4 ; int32_T eg2jort0pr ; uint32_T
jzep2ohrnb ; uint32_T cilbx3vx24 [ 2 ] ; uint32_T ipxmf4nqid ; uint32_T
jtu10ruen3 ; uint32_T mzg215i5rt [ 2 ] ; uint32_T g2vriuglhe ; uint32_T
a4c5w1arfv [ 2 ] ; uint32_T obyhwmpjsf ; uint32_T ogxukxdqv1 [ 2 ] ; uint32_T
n31srl0ta1 ; uint32_T d4n3n2cdul [ 2 ] ; uint32_T esk3qjuuyz ; uint32_T
l5smgwi0v4 [ 2 ] ; uint32_T ipofyrmiwn ; uint32_T ivxkbodq3l [ 2 ] ; uint32_T
eu4vs0xpws ; uint32_T kfwnufufc2 [ 2 ] ; uint32_T c0ngrxialj ; uint32_T
pg42bwzhxn [ 2 ] ; boolean_T bbg0ornexh ; char_T m4qkiriyhv [ 7 ] ;
nfxat0gzy0 jrktoyg454 ; aew4ycrzmw cmk1zthcws ; fdttpjehtz eggjh25mqq ;
dfrs4csji4 hz1mnqzl1y ; i55gxqlq5v pqmmaxbcof ; iupcmfgd0d mjapvf1lgb ;
nfxat0gzy0 d4n1mndcab ; aew4ycrzmw iecvxru0fq ; fdttpjehtz nonwoibfph ;
dfrs4csji4 ofbg4zsgr3 ; i55gxqlq5v pp24nkf1uv ; iupcmfgd0d har3srfjuf ;
nfxat0gzy0 oldceuyjbn ; aew4ycrzmw fpkrai54nt ; fdttpjehtz kflp23vorx ;
dfrs4csji4 p3ag23wbx2 ; i55gxqlq5v fn1p0l3god ; iupcmfgd0d bwcnmwh5li ;
nfxat0gzy0 hzgknpwv0s ; aew4ycrzmw lj2evounis ; fdttpjehtz elrh2co23o ;
dfrs4csji4 m04d0vrz2a ; i55gxqlq5v enhordppbg ; iupcmfgd0d ll55pbxqy4 ;
nfxat0gzy0 ewvjgp1nzs ; aew4ycrzmw cppnd2oryp ; fdttpjehtz fudhuw3f20 ;
dfrs4csji4 jf5pcxexaq ; i55gxqlq5v jfilkpibyz ; iupcmfgd0d ggy2cecwzd ;
nfxat0gzy0 kvximfh40t ; aew4ycrzmw btqoy2p2mc ; fdttpjehtz j0kqqyp53z ;
dfrs4csji4 hkmt2lurcp ; i55gxqlq5v hxceaqj1j4 ; iupcmfgd0d o0lz1yta15 ;
nfxat0gzy0 gnvseqstkw ; aew4ycrzmw d42rppglcr ; fdttpjehtz jv3cnfubul ;
dfrs4csji4 ptytfvjmyf ; i55gxqlq5v ldc0papvgx ; iupcmfgd0d eysgxtzln4 ;
nfxat0gzy0 dm45ptzaogh ; aew4ycrzmw azbbgayip0e ; fdttpjehtz ehval41szii ;
dfrs4csji4 e1euhyqxusi ; i55gxqlq5v bgnxdoxzrso ; iupcmfgd0d ke3md013gpf ; }
j4fbbnriyn ; typedef struct { real_T dvbmkqfu5k [ 16 ] ; creal_T naxvq33ygv ;
} krutpss5fb ; struct hfcskoczds_ { real_T P_0 ; } ; struct mgpn43wxg5_ {
real_T P_0 ; real_T P_1 ; real_T P_2 ; real_T P_3 ; real_T P_4 ; real_T P_5 ;
real_T P_6 ; real_T P_7 ; real_T P_8 ; real_T P_9 ; real_T P_10 ; real_T P_11
; real_T P_12 ; real_T P_13 ; } ; struct gk4zctqeq4_ { real_T P_0 ; real_T
P_1 ; real_T P_2 ; real_T P_3 ; real_T P_4 ; real_T P_5 ; real_T P_6 ; real_T
P_7 ; real_T P_8 ; real_T P_9 ; } ; struct f0ewbxt5x2_ { real_T P_0 ; real_T
P_1 ; real_T P_2 ; real_T P_3 ; real_T P_4 ; real_T P_5 ; real_T P_6 ; real_T
P_7 ; } ; struct dckodiwito_ { real_T P_0 ; real_T P_1 ; real_T P_2 ; real_T
P_3 ; real_T P_4 ; real_T P_5 ; real_T P_6 ; real_T P_7 ; real_T P_8 ; real_T
P_9 ; real_T P_10 ; real_T P_11 ; } ; struct fpi4j2c0ib_ { real_T P_0 ;
real_T P_1 ; real_T P_2 ; real_T P_3 ; real_T P_4 ; real_T P_5 ; } ; struct
cr0syazknf_ { real_T P_0 ; real_T P_1 ; real_T P_2 ; real_T P_3 ; real_T P_4
; real_T P_5 ; real_T P_6 ; real_T P_7 ; real_T P_8 [ 88 ] ; real_T P_9 [ 2 ]
; real_T P_10 ; real_T P_11 ; real_T P_12 ; real_T P_13 ; real_T P_14 ;
real_T P_15 ; real_T P_16 ; real_T P_17 [ 4 ] ; real_T P_18 ; real_T P_19 ;
real_T P_20 ; real_T P_21 ; real_T P_22 ; real_T P_23 ; real_T P_24 ; real_T
P_25 ; real_T P_26 ; real_T P_27 ; real_T P_28 ; real_T P_29 ; real_T P_30 ;
real_T P_31 ; real_T P_32 ; real_T P_33 ; real_T P_34 ; real_T P_35 ; real_T
P_36 ; real_T P_37 ; real_T P_38 ; real_T P_39 ; real_T P_40 ; real_T P_41 ;
real_T P_42 ; real_T P_43 ; real_T P_44 ; real_T P_45 ; real_T P_46 ; real_T
P_47 ; real_T P_48 ; real_T P_49 ; real_T P_50 ; real_T P_51 ; real_T P_52 ;
real_T P_53 ; real_T P_54 ; real_T P_55 ; real_T P_56 ; real_T P_57 ; real_T
P_58 ; real_T P_59 ; real_T P_60 ; real_T P_61 ; real_T P_62 ; real_T P_63 ;
real_T P_64 ; real_T P_65 ; real_T P_66 ; real_T P_67 ; real_T P_68 ; real_T
P_69 ; real_T P_70 ; real_T P_71 ; real_T P_72 ; real_T P_73 ; real_T P_74 ;
real_T P_75 ; real_T P_76 ; real_T P_77 ; real_T P_78 ; real_T P_79 ; real_T
P_80 ; real_T P_81 ; real_T P_82 ; real_T P_83 ; real_T P_84 ; real_T P_85 ;
real_T P_86 ; real_T P_87 ; real_T P_88 ; real_T P_89 ; real_T P_90 ; real_T
P_91 ; real_T P_92 ; real_T P_93 ; real_T P_94 ; real_T P_95 ; real_T P_96 ;
real_T P_97 ; real_T P_98 ; real_T P_99 ; real_T P_100 ; real_T P_101 ;
real_T P_102 ; real_T P_103 [ 88 ] ; real_T P_104 ; creal_T P_105 ; creal_T
P_106 ; creal_T P_107 ; creal_T P_108 ; creal_T P_109 ; creal_T P_110 ;
creal_T P_111 ; creal_T P_112 ; creal_T P_113 ; uint32_T P_114 ; uint32_T
P_115 ; uint32_T P_116 ; uint32_T P_117 ; uint32_T P_118 ; uint32_T P_119 ;
uint32_T P_120 ; uint32_T P_121 ; uint32_T P_122 ; uint32_T P_123 ; uint32_T
P_124 ; uint32_T P_125 ; uint32_T P_126 ; char_T lknhm3kbxm [ 4 ] ;
fpi4j2c0ib jrktoyg454 ; dckodiwito cmk1zthcws ; f0ewbxt5x2 eggjh25mqq ;
gk4zctqeq4 hz1mnqzl1y ; mgpn43wxg5 pqmmaxbcof ; hfcskoczds mjapvf1lgb ;
fpi4j2c0ib d4n1mndcab ; dckodiwito iecvxru0fq ; f0ewbxt5x2 nonwoibfph ;
gk4zctqeq4 ofbg4zsgr3 ; mgpn43wxg5 pp24nkf1uv ; hfcskoczds har3srfjuf ;
fpi4j2c0ib oldceuyjbn ; dckodiwito fpkrai54nt ; f0ewbxt5x2 kflp23vorx ;
gk4zctqeq4 p3ag23wbx2 ; mgpn43wxg5 fn1p0l3god ; hfcskoczds bwcnmwh5li ;
fpi4j2c0ib hzgknpwv0s ; dckodiwito lj2evounis ; f0ewbxt5x2 elrh2co23o ;
gk4zctqeq4 m04d0vrz2a ; mgpn43wxg5 enhordppbg ; hfcskoczds ll55pbxqy4 ;
fpi4j2c0ib ewvjgp1nzs ; dckodiwito cppnd2oryp ; f0ewbxt5x2 fudhuw3f20 ;
gk4zctqeq4 jf5pcxexaq ; mgpn43wxg5 jfilkpibyz ; hfcskoczds ggy2cecwzd ;
fpi4j2c0ib kvximfh40t ; dckodiwito btqoy2p2mc ; f0ewbxt5x2 j0kqqyp53z ;
gk4zctqeq4 hkmt2lurcp ; mgpn43wxg5 hxceaqj1j4 ; hfcskoczds o0lz1yta15 ;
fpi4j2c0ib gnvseqstkw ; dckodiwito d42rppglcr ; f0ewbxt5x2 jv3cnfubul ;
gk4zctqeq4 ptytfvjmyf ; mgpn43wxg5 ldc0papvgx ; hfcskoczds eysgxtzln4 ;
fpi4j2c0ib dm45ptzaogh ; dckodiwito azbbgayip0e ; f0ewbxt5x2 ehval41szii ;
gk4zctqeq4 e1euhyqxusi ; mgpn43wxg5 bgnxdoxzrso ; hfcskoczds ke3md013gpf ; }
; extern cr0syazknf gr03u5oqod ; extern const krutpss5fb c4ffeboaz1 ;
#endif
