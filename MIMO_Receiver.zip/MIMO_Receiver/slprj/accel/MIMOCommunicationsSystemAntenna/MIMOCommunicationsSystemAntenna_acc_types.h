#include "__cf_MIMOCommunicationsSystemAntenna.h"
#ifndef RTW_HEADER_MIMOCommunicationsSystemAntenna_acc_types_h_
#define RTW_HEADER_MIMOCommunicationsSystemAntenna_acc_types_h_
#include "rtwtypes.h"
#include "multiword_types.h"
typedef struct kk12dnfhwu_ kk12dnfhwu ;
#endif
