#include "__cf_MIMOCommunicationsSystemAntenna.h"
#include <math.h>
#include "MIMOCommunicationsSystemAntenna_acc.h"
#include "MIMOCommunicationsSystemAntenna_acc_private.h"
#include <stdio.h>
#include "slexec_vm_simstruct_bridge.h"
#include "slexec_vm_zc_functions.h"
#include "slexec_vm_lookup_functions.h"
#include "simstruc.h"
#include "fixedpoint.h"
#define CodeFormat S-Function
#define AccDefine1 Accelerator_S-Function
#include "simtarget/slAccSfcnBridge.h"
void RandSrcInitState_U_64 ( const uint32_T seed [ ] , real_T state [ ] ,
int32_T nChans ) { int32_T i ; uint32_T j ; int32_T k ; int32_T n ; real_T d
; for ( i = 0 ; i < nChans ; i ++ ) { j = seed [ i ] != 0U ? seed [ i ] :
2147483648U ; state [ 35 * i + 34 ] = j ; for ( k = 0 ; k < 32 ; k ++ ) { d =
0.0 ; for ( n = 0 ; n < 53 ; n ++ ) { j ^= j << 13 ; j ^= j >> 17 ; j ^= j <<
5 ; d = ( real_T ) ( ( int32_T ) ( j >> 19 ) & 1 ) + ( d + d ) ; } state [ 35
* i + k ] = ldexp ( d , - 53 ) ; } state [ 35 * i + 32 ] = 0.0 ; state [ 35 *
i + 33 ] = 0.0 ; } } void RandSrcInitState_GZ ( const uint32_T seed [ ] ,
uint32_T state [ ] , int32_T nChans ) { int32_T i ; for ( i = 0 ; i < nChans
; i ++ ) { state [ i << 1 ] = 362436069U ; state [ ( i << 1 ) + 1 ] = seed [
i ] == 0U ? 521288629U : seed [ i ] ; } } void RandSrc_U_D ( real_T y [ ] ,
const real_T minVec [ ] , int32_T minLen , const real_T maxVec [ ] , int32_T
maxLen , real_T state [ ] , int32_T nChans , int32_T nSamps ) { int32_T one ;
int32_T lsw ; int8_T * onePtr ; int32_T chan ; real_T min ; real_T max ;
int32_T samps ; real_T d ; int32_T i ; uint32_T j ; int32_T ii [ 2 ] ; one =
1 ; onePtr = ( int8_T * ) & one ; lsw = ( onePtr [ 0U ] == 0 ) ; for ( chan =
0 ; chan < nChans ; chan ++ ) { min = minVec [ minLen > 1 ? chan : 0 ] ; max
= maxVec [ maxLen > 1 ? chan : 0 ] ; max -= min ; i = ( int32_T ) ( (
uint32_T ) state [ chan * 35 + 33 ] & 31U ) ; j = ( uint32_T ) state [ chan *
35 + 34 ] ; for ( samps = 0 ; samps < nSamps ; samps ++ ) { d = state [ ( ( i
+ 20 ) & 31 ) + chan * 35 ] ; d -= state [ ( ( i + 5 ) & 31 ) + chan * 35 ] ;
d -= state [ chan * 35 + 32 ] ; if ( d >= 0.0 ) { state [ chan * 35 + 32 ] =
0.0 ; } else { d ++ ; state [ chan * 35 + 32 ] = 1.1102230246251565E-16 ; }
state [ chan * 35 + i ] = d ; i = ( i + 1 ) & 31 ; memcpy ( & ii [ 0U ] , & d
, sizeof ( real_T ) ) ; ii [ lsw ] ^= j ; j ^= j << 13 ; j ^= j >> 17 ; j ^=
j << 5 ; ii [ lsw ^ 1 ] ^= j & 1048575U ; memcpy ( & d , & ii [ 0U ] , sizeof
( real_T ) ) ; y [ chan * nSamps + samps ] = max * d + min ; } state [ chan *
35 + 33 ] = i ; state [ chan * 35 + 34 ] = j ; } } void RandSrc_GZ_Z (
creal_T y [ ] , const creal_T mean [ ] , int32_T meanLen , const real_T xstd
[ ] , int32_T xstdLen , uint32_T state [ ] , int32_T nChans , int32_T nSamps
) { int32_T i ; int32_T j ; real_T r ; real_T x ; real_T s ; real_T y_p ;
int32_T chan ; real_T std ; uint32_T icng ; uint32_T jsr ; int32_T samp ;
real_T resultsVal [ 2 ] ; real_T mean_p [ 2 ] ; static const real_T vt [ 65 ]
= { 0.340945 , 0.4573146 , 0.5397793 , 0.6062427 , 0.6631691 , 0.7136975 ,
0.7596125 , 0.8020356 , 0.8417227 , 0.8792102 , 0.9148948 , 0.9490791 ,
0.9820005 , 1.0138492 , 1.044781 , 1.0749254 , 1.1043917 , 1.1332738 ,
1.161653 , 1.189601 , 1.2171815 , 1.2444516 , 1.2714635 , 1.298265 ,
1.3249008 , 1.3514125 , 1.3778399 , 1.4042211 , 1.4305929 , 1.4569915 ,
1.4834527 , 1.5100122 , 1.5367061 , 1.5635712 , 1.5906454 , 1.617968 ,
1.6455802 , 1.6735255 , 1.7018503 , 1.7306045 , 1.7598422 , 1.7896223 ,
1.8200099 , 1.851077 , 1.8829044 , 1.9155831 , 1.9492166 , 1.9839239 ,
2.0198431 , 2.0571356 , 2.095993 , 2.136645 , 2.1793713 , 2.2245175 ,
2.2725186 , 2.3239338 , 2.3795008 , 2.4402218 , 2.5075117 , 2.5834658 ,
2.6713916 , 2.7769942 , 2.7769942 , 2.7769942 , 2.7769942 } ; nSamps +=
nSamps ; for ( chan = 0 ; chan < nChans ; chan ++ ) { std = xstd [ xstdLen >
1 ? chan : 0 ] ; icng = state [ chan << 1 ] ; jsr = state [ ( chan << 1 ) + 1
] ; mean_p [ 0U ] = mean [ meanLen > 1 ? chan : 0 ] . re ; mean_p [ 1U ] =
mean [ meanLen > 1 ? chan : 0 ] . im ; for ( samp = 0 ; samp < nSamps ; samp
++ ) { icng = 69069U * icng + 1234567U ; jsr ^= jsr << 13 ; jsr ^= jsr >> 17
; jsr ^= jsr << 5 ; i = ( int32_T ) ( icng + jsr ) ; j = ( i & 63 ) + 1 ; r =
( real_T ) i * 4.6566128730773926E-10 * vt [ j ] ; if ( ! ( muDoubleScalarAbs
( r ) <= vt [ j - 1 ] ) ) { x = ( muDoubleScalarAbs ( r ) - vt [ j - 1 ] ) /
( vt [ j ] - vt [ j - 1 ] ) ; icng = 69069U * icng + 1234567U ; jsr ^= jsr <<
13 ; jsr ^= jsr >> 17 ; jsr ^= jsr << 5 ; y_p = ( real_T ) ( int32_T ) ( icng
+ jsr ) * 2.328306436538696E-10 + 0.5 ; s = x + y_p ; if ( s > 1.301198 ) { r
= r < 0.0 ? 0.4878992 * x - 0.4878992 : 0.4878992 - 0.4878992 * x ; } else {
if ( ! ( s <= 0.9689279 ) ) { x = 0.4878992 - 0.4878992 * x ; if ( y_p >
12.67706 - muDoubleScalarExp ( - 0.5 * x * x ) * 12.37586 ) { r = r < 0.0 ? -
x : x ; } else { if ( ! ( muDoubleScalarExp ( - 0.5 * vt [ j ] * vt [ j ] ) +
y_p * 0.01958303 / vt [ j ] <= muDoubleScalarExp ( - 0.5 * r * r ) ) ) { do {
icng = 69069U * icng + 1234567U ; jsr ^= jsr << 13 ; jsr ^= jsr >> 17 ; jsr
^= jsr << 5 ; x = muDoubleScalarLog ( ( real_T ) ( int32_T ) ( icng + jsr ) *
2.328306436538696E-10 + 0.5 ) / 2.776994 ; icng = 69069U * icng + 1234567U ;
jsr ^= jsr << 13 ; jsr ^= jsr >> 17 ; jsr ^= jsr << 5 ; } while (
muDoubleScalarLog ( ( real_T ) ( int32_T ) ( icng + jsr ) *
2.328306436538696E-10 + 0.5 ) * - 2.0 <= x * x ) ; r = r < 0.0 ? x - 2.776994
: 2.776994 - x ; } } } } } resultsVal [ samp & 1 ] = mean_p [ samp & 1 ] +
std * r ; if ( ( samp & 1 ) != 0 ) { y [ chan * ( nSamps >> 1 ) + ( samp >> 1
) ] . re = resultsVal [ 0U ] ; y [ chan * ( nSamps >> 1 ) + ( samp >> 1 ) ] .
im = resultsVal [ 1U ] ; } } state [ chan << 1 ] = icng ; state [ ( chan << 1
) + 1 ] = jsr ; } } static void mdlOutputs ( SimStruct * S , int_T tid ) {
int32_T firstIteration ; int32_T coefArrayIdx ; int32_T outBufIdx1 ; int32_T
tapIdx ; real_T alixvjqnkb ; creal_T lnrpexhl3s [ 8 ] ; creal_T mnbn5mepwj [
8 ] ; int32_T tmp ; creal_T o51ww2yeyv ; int32_T i ; real_T accumulator_im ;
pbkhgmqfhj * _rtB ; kk12dnfhwu * _rtP ; i1yaupu10n * _rtDW ; _rtDW = ( (
i1yaupu10n * ) ssGetRootDWork ( S ) ) ; _rtP = ( ( kk12dnfhwu * )
ssGetModelRtp ( S ) ) ; _rtB = ( ( pbkhgmqfhj * ) _ssGetModelBlockIO ( S ) )
; ssCallAccelRunBlock ( S , 7 , 0 , SS_CALL_MDL_OUTPUTS ) ; if (
ssIsSampleHit ( S , 1 , 0 ) ) { _rtB -> ofucmz2zxf = _rtDW -> flogptrx0i ; }
memcpy ( & _rtB -> f04p0h5xcg [ 0 ] , & _rtDW -> esc5m5vnbf [ 0 ] , sizeof (
creal_T ) << 3U ) ; ssCallAccelRunBlock ( S , 2 , 0 , SS_CALL_MDL_OUTPUTS ) ;
_rtB -> c0tmtbohwi [ 0 ] = _rtP -> P_4 * _rtB -> nv0t0zngs5 [ 0 ] + _rtP ->
P_5 ; _rtB -> c0tmtbohwi [ 1 ] = _rtP -> P_4 * _rtB -> nv0t0zngs5 [ 1 ] +
_rtP -> P_5 ; ssCallAccelRunBlock ( S , 0 , 0 , SS_CALL_MDL_OUTPUTS ) ;
ssCallAccelRunBlock ( S , 7 , 7 , SS_CALL_MDL_OUTPUTS ) ; if ( ssIsSampleHit
( S , 1 , 0 ) ) { ssCallAccelRunBlock ( S , 7 , 8 , SS_CALL_MDL_OUTPUTS ) ; }
ssCallAccelRunBlock ( S , 7 , 9 , SS_CALL_MDL_OUTPUTS ) ; ssCallAccelRunBlock
( S , 7 , 10 , SS_CALL_MDL_OUTPUTS ) ; if ( ssIsSampleHit ( S , 1 , 0 ) ) {
RandSrc_U_D ( & alixvjqnkb , & _rtP -> P_6 , 1 , & _rtP -> P_7 , 1 , _rtDW ->
kda0v4lrgi , 1 , 1 ) ; alixvjqnkb = muDoubleScalarCeil ( alixvjqnkb ) ; tmp =
( int32_T ) alixvjqnkb ; _rtB -> jw2wm0s2f4 . re = ons3ryuomj . o0feirr2kh [
tmp << 1 ] ; _rtB -> jw2wm0s2f4 . im = ons3ryuomj . o0feirr2kh [ ( tmp << 1 )
+ 1 ] ; if ( _rtDW -> i3itx51vij ) { outBufIdx1 = 8 ; } else { outBufIdx1 = 0
; } for ( tapIdx = 0 ; tapIdx < 8 ; tapIdx ++ ) { firstIteration = outBufIdx1
+ tapIdx ; coefArrayIdx = tapIdx * 11 ; for ( i = 1 ; i - 1 < 1 ; i ++ ) {
alixvjqnkb = 0.0 ; accumulator_im = 0.0 ; for ( tmp = 0 ; tmp < i ; tmp ++ )
{ alixvjqnkb += _rtP -> P_8 [ coefArrayIdx + tmp ] * _rtB -> jw2wm0s2f4 . re
; accumulator_im += _rtP -> P_8 [ coefArrayIdx + tmp ] * _rtB -> jw2wm0s2f4 .
im ; } for ( tmp = 0 ; tmp < 11 - i ; tmp ++ ) { alixvjqnkb += _rtP -> P_8 [
( coefArrayIdx + i ) + tmp ] * _rtDW -> p2svfersay [ tmp ] . re ;
accumulator_im += _rtP -> P_8 [ ( coefArrayIdx + i ) + tmp ] * _rtDW ->
p2svfersay [ tmp ] . im ; } _rtDW -> hchdohea45 [ firstIteration ] . re =
alixvjqnkb ; _rtDW -> hchdohea45 [ firstIteration ] . im = accumulator_im ;
firstIteration += 8 ; } } for ( i = 8 ; i >= 0 ; i -- ) { _rtDW -> p2svfersay
[ 1 + i ] = _rtDW -> p2svfersay [ i ] ; } _rtDW -> p2svfersay [ 0 ] = _rtB ->
jw2wm0s2f4 ; _rtDW -> i3itx51vij = ! _rtDW -> i3itx51vij ; } _rtB ->
peohwd3r2y = _rtDW -> hchdohea45 [ _rtDW -> oraurqjq0g ] ; _rtDW ->
oraurqjq0g ++ ; if ( _rtDW -> oraurqjq0g >= 16 ) { _rtDW -> oraurqjq0g = 0 ;
} ssCallAccelRunBlock ( S , 6 , 0 , SS_CALL_MDL_OUTPUTS ) ; _rtB ->
m5dp5uomo3 . re = _rtP -> P_10 * _rtB -> pj4mem3kuv . re ; _rtB -> m5dp5uomo3
. im = _rtP -> P_10 * _rtB -> pj4mem3kuv . im ; outBufIdx1 = 1 ; tmp = 2048 -
_rtDW -> gxeafjckjp ; firstIteration = _rtDW -> gxeafjckjp ; if ( tmp <= 1 )
{ i = 0 ; while ( i < tmp ) { _rtDW -> pdujkx1sa4 [ _rtDW -> gxeafjckjp ] =
_rtB -> m5dp5uomo3 ; i = 1 ; } firstIteration = 0 ; outBufIdx1 = 1 - tmp ; }
for ( i = 0 ; i < outBufIdx1 ; i ++ ) { _rtDW -> pdujkx1sa4 [ firstIteration
+ i ] = _rtB -> m5dp5uomo3 ; } _rtDW -> gxeafjckjp ++ ; if ( _rtDW ->
gxeafjckjp >= 2048 ) { _rtDW -> gxeafjckjp -= 2048 ; } _rtDW -> fiieqq1x12 ++
; if ( _rtDW -> fiieqq1x12 > 2048 ) { _rtDW -> gsqquqdonp = ( _rtDW ->
gsqquqdonp + _rtDW -> fiieqq1x12 ) - 2048 ; if ( _rtDW -> gsqquqdonp > 2048 )
{ _rtDW -> gsqquqdonp -= 2048 ; } _rtDW -> fiieqq1x12 = 2048 ; } if (
ssIsSampleHit ( S , 2 , 0 ) ) { _rtDW -> fiieqq1x12 -= 1024 ; if ( _rtDW ->
fiieqq1x12 < 0 ) { _rtDW -> gsqquqdonp += _rtDW -> fiieqq1x12 ; if ( _rtDW ->
gsqquqdonp < 0 ) { _rtDW -> gsqquqdonp += 2048 ; } _rtDW -> fiieqq1x12 = 0 ;
} firstIteration = 0 ; tapIdx = _rtDW -> gsqquqdonp ; if ( _rtDW ->
gsqquqdonp < 0 ) { tapIdx = _rtDW -> gsqquqdonp + 2048 ; } tmp = 2048 -
tapIdx ; outBufIdx1 = 1024 ; if ( tmp <= 1024 ) { for ( i = 0 ; i < tmp ; i
++ ) { _rtB -> l0jcestug0 [ i ] = _rtDW -> pdujkx1sa4 [ tapIdx + i ] ; }
firstIteration = tmp ; tapIdx = 0 ; outBufIdx1 = 1024 - tmp ; } for ( i = 0 ;
i < outBufIdx1 ; i ++ ) { _rtB -> l0jcestug0 [ firstIteration + i ] = _rtDW
-> pdujkx1sa4 [ tapIdx + i ] ; } _rtDW -> gsqquqdonp = tapIdx + outBufIdx1 ;
for ( i = 0 ; i < 1024 ; i ++ ) { _rtB -> ckje4ybdnk [ i ] = _rtB ->
l0jcestug0 [ i ] . re * _rtB -> l0jcestug0 [ i ] . re + _rtB -> l0jcestug0 [
i ] . im * _rtB -> l0jcestug0 [ i ] . im ; } alixvjqnkb = _rtB -> ckje4ybdnk
[ 0 ] ; for ( outBufIdx1 = 0 ; outBufIdx1 < 1023 ; outBufIdx1 ++ ) {
alixvjqnkb += _rtB -> ckje4ybdnk [ outBufIdx1 + 1 ] ; } alixvjqnkb =
muDoubleScalarSqrt ( _rtP -> P_12 * alixvjqnkb ) + _rtB -> nnu4uc1syw ; _rtB
-> mlytsoph5n = muDoubleScalarLog10 ( alixvjqnkb * alixvjqnkb * _rtP -> P_14
) * _rtP -> P_15 + _rtB -> hvoemigjvv ; ssCallAccelRunBlock ( S , 7 , 31 ,
SS_CALL_MDL_OUTPUTS ) ; } RandSrc_GZ_Z ( & o51ww2yeyv , & _rtP -> P_141 , 1 ,
& _rtP -> P_17 , 1 , _rtDW -> c1asta4g2l , 1 , 1 ) ; _rtDW -> f2lifjbstj =
muDoubleScalarSqrt ( _rtP -> P_19 / muDoubleScalarPower ( 10.0 , _rtP -> P_18
/ 10.0 ) ) ; _rtB -> cdmgsncqw3 [ 0 ] . re = _rtDW -> f2lifjbstj * o51ww2yeyv
. re ; _rtB -> cdmgsncqw3 [ 0 ] . im = _rtDW -> f2lifjbstj * o51ww2yeyv . im
; _rtB -> cdmgsncqw3 [ 0 ] . re += _rtB -> m5dp5uomo3 . re ; _rtB ->
cdmgsncqw3 [ 0 ] . im += _rtB -> m5dp5uomo3 . im ; _rtB -> cdmgsncqw3 [ 1 ] .
re = _rtP -> P_20 * muDoubleScalarCos ( _rtDW -> cifo5ryfmy ) ; _rtB ->
cdmgsncqw3 [ 1 ] . im = _rtP -> P_20 * muDoubleScalarSin ( _rtDW ->
cifo5ryfmy ) ; _rtDW -> cifo5ryfmy += _rtP -> P_21 * 5.4541818377503123E-7 ;
if ( _rtDW -> cifo5ryfmy >= 6.2831853071795862 ) { _rtDW -> cifo5ryfmy -=
6.2831853071795862 ; } else { if ( _rtDW -> cifo5ryfmy < 0.0 ) { _rtDW ->
cifo5ryfmy += 6.2831853071795862 ; } } ssCallAccelRunBlock ( S , 7 , 36 ,
SS_CALL_MDL_OUTPUTS ) ; if ( ssIsSampleHit ( S , 1 , 0 ) ) {
ssCallAccelRunBlock ( S , 7 , 37 , SS_CALL_MDL_OUTPUTS ) ; }
ssCallAccelRunBlock ( S , 1 , 0 , SS_CALL_MDL_OUTPUTS ) ; ssCallAccelRunBlock
( S , 3 , 0 , SS_CALL_MDL_OUTPUTS ) ; tmp = _rtDW -> du1ibzcrkb + 1 ; i =
_rtDW -> jdvmc5mj11 ; outBufIdx1 = ( _rtDW -> du1ibzcrkb + 1 ) * 10 ; _rtDW
-> kv525arykn . re += _rtB -> k2rrql51fk . re * _rtP -> P_23 [ _rtDW ->
hviauzhe2p ] ; _rtDW -> kv525arykn . im += _rtB -> k2rrql51fk . im * _rtP ->
P_23 [ _rtDW -> hviauzhe2p ] ; tapIdx = _rtDW -> hviauzhe2p + 1 ; for (
firstIteration = _rtDW -> beglvs0poa + 1 ; firstIteration < outBufIdx1 ;
firstIteration ++ ) { _rtDW -> kv525arykn . re += _rtDW -> jqxvcvqwf2 [
firstIteration ] . re * _rtP -> P_23 [ tapIdx ] ; _rtDW -> kv525arykn . im +=
_rtDW -> jqxvcvqwf2 [ firstIteration ] . im * _rtP -> P_23 [ tapIdx ] ;
tapIdx ++ ; } for ( firstIteration = outBufIdx1 - 10 ; firstIteration <=
_rtDW -> beglvs0poa ; firstIteration ++ ) { _rtDW -> kv525arykn . re += _rtDW
-> jqxvcvqwf2 [ firstIteration ] . re * _rtP -> P_23 [ tapIdx ] ; _rtDW ->
kv525arykn . im += _rtDW -> jqxvcvqwf2 [ firstIteration ] . im * _rtP -> P_23
[ tapIdx ] ; tapIdx ++ ; } _rtDW -> jqxvcvqwf2 [ _rtDW -> beglvs0poa ] = _rtB
-> k2rrql51fk ; outBufIdx1 = _rtDW -> beglvs0poa + 10 ; if ( outBufIdx1 >= 80
) { outBufIdx1 -= 80 ; } if ( ! ( tmp < 8 ) ) { _rtDW -> ms5fgk0gxi = _rtDW
-> kv525arykn ; i = _rtDW -> jdvmc5mj11 + 1 ; _rtDW -> kv525arykn . re = 0.0
; _rtDW -> kv525arykn . im = 0.0 ; tmp = 0 ; tapIdx = 0 ; outBufIdx1 -- ; if
( outBufIdx1 < 0 ) { outBufIdx1 += 10 ; } } _rtDW -> beglvs0poa = outBufIdx1
; _rtDW -> hviauzhe2p = tapIdx ; _rtDW -> du1ibzcrkb = tmp ; _rtDW ->
jdvmc5mj11 = i ; if ( ssIsSpecialSampleHit ( S , 1 , 0 , 0 ) ) { _rtB ->
lgmd2mwofl = _rtDW -> ms5fgk0gxi ; _rtDW -> jdvmc5mj11 = 0 ; } if (
ssIsSampleHit ( S , 1 , 0 ) ) { _rtB -> cwvo5qlhfv = _rtDW -> ecakfpli3v [ 0
] ; ssCallAccelRunBlock ( S , 4 , 0 , SS_CALL_MDL_OUTPUTS ) ; }
ssCallAccelRunBlock ( S , 5 , 0 , SS_CALL_MDL_OUTPUTS ) ; _rtB -> pyrzixe3vr
[ 0 ] = _rtB -> b1umqs1b4l ; _rtB -> pyrzixe3vr [ 1 ] = 0.0 ; _rtB ->
pyrzixe3vr [ 2 ] = 0.0 ; _rtDW -> ile1b2yo31 [ 0 ] = ! ( _rtB -> pyrzixe3vr [
0 ] == _rtDW -> ile1b2yo31 [ 1 ] ) ; _rtDW -> ile1b2yo31 [ 1 ] = _rtB ->
pyrzixe3vr [ 0 ] ; _rtB -> pyrzixe3vr [ 3 ] = _rtDW -> ile1b2yo31 [ 0 ] ;
_rtB -> gopd3gcpky [ 0 ] = _rtB -> ikxig5qnsy ; _rtB -> gopd3gcpky [ 1 ] =
0.0 ; _rtB -> gopd3gcpky [ 2 ] = 0.0 ; _rtDW -> igd3fzbbzj [ 0 ] = ! ( _rtB
-> gopd3gcpky [ 0 ] == _rtDW -> igd3fzbbzj [ 1 ] ) ; _rtDW -> igd3fzbbzj [ 1
] = _rtB -> gopd3gcpky [ 0 ] ; _rtB -> gopd3gcpky [ 3 ] = _rtDW -> igd3fzbbzj
[ 0 ] ; _rtB -> bmtoaw0gtq [ 0 ] = _rtB -> p3qravtszj ; _rtB -> bmtoaw0gtq [
1 ] = 0.0 ; _rtB -> bmtoaw0gtq [ 2 ] = 0.0 ; _rtDW -> fdnbnjyniv [ 0 ] = ! (
_rtB -> bmtoaw0gtq [ 0 ] == _rtDW -> fdnbnjyniv [ 1 ] ) ; _rtDW -> fdnbnjyniv
[ 1 ] = _rtB -> bmtoaw0gtq [ 0 ] ; _rtB -> bmtoaw0gtq [ 3 ] = _rtDW ->
fdnbnjyniv [ 0 ] ; _rtB -> f21cltugzr [ 0 ] = _rtB -> kx2qqzmggx ; _rtB ->
f21cltugzr [ 1 ] = 0.0 ; _rtB -> f21cltugzr [ 2 ] = 0.0 ; _rtDW -> o0om0itt4q
[ 0 ] = ! ( _rtB -> f21cltugzr [ 0 ] == _rtDW -> o0om0itt4q [ 1 ] ) ; _rtDW
-> o0om0itt4q [ 1 ] = _rtB -> f21cltugzr [ 0 ] ; _rtB -> f21cltugzr [ 3 ] =
_rtDW -> o0om0itt4q [ 0 ] ; _rtB -> cdc5zqwqat [ 0 ] = _rtB -> btt5uk3us0 ;
_rtB -> cdc5zqwqat [ 1 ] = 0.0 ; _rtB -> cdc5zqwqat [ 2 ] = 0.0 ; _rtDW ->
pnaj4gzh0y [ 0 ] = ! ( _rtB -> cdc5zqwqat [ 0 ] == _rtDW -> pnaj4gzh0y [ 1 ]
) ; _rtDW -> pnaj4gzh0y [ 1 ] = _rtB -> cdc5zqwqat [ 0 ] ; _rtB -> cdc5zqwqat
[ 3 ] = _rtDW -> pnaj4gzh0y [ 0 ] ; _rtB -> o3sk2tzt1m [ 0 ] = _rtB ->
c4ws3q4l4q ; _rtB -> o3sk2tzt1m [ 1 ] = 0.0 ; _rtB -> o3sk2tzt1m [ 2 ] = 0.0
; _rtDW -> bf0btitteq [ 0 ] = ! ( _rtB -> o3sk2tzt1m [ 0 ] == _rtDW ->
bf0btitteq [ 1 ] ) ; _rtDW -> bf0btitteq [ 1 ] = _rtB -> o3sk2tzt1m [ 0 ] ;
_rtB -> o3sk2tzt1m [ 3 ] = _rtDW -> bf0btitteq [ 0 ] ; _rtB -> ippf2ytuvu [ 0
] = _rtB -> il0tqwy43f ; _rtB -> ippf2ytuvu [ 1 ] = 0.0 ; _rtB -> ippf2ytuvu
[ 2 ] = 0.0 ; _rtDW -> f1vbjebjie [ 0 ] = ! ( _rtB -> ippf2ytuvu [ 0 ] ==
_rtDW -> f1vbjebjie [ 1 ] ) ; _rtDW -> f1vbjebjie [ 1 ] = _rtB -> ippf2ytuvu
[ 0 ] ; _rtB -> ippf2ytuvu [ 3 ] = _rtDW -> f1vbjebjie [ 0 ] ; _rtB ->
fq0j2mezqy [ 0 ] = _rtB -> hganx4hmy5 ; _rtB -> fq0j2mezqy [ 1 ] = 0.0 ; _rtB
-> fq0j2mezqy [ 2 ] = 0.0 ; _rtDW -> fn0rzkf5dz [ 0 ] = ! ( _rtB ->
fq0j2mezqy [ 0 ] == _rtDW -> fn0rzkf5dz [ 1 ] ) ; _rtDW -> fn0rzkf5dz [ 1 ] =
_rtB -> fq0j2mezqy [ 0 ] ; _rtB -> fq0j2mezqy [ 3 ] = _rtDW -> fn0rzkf5dz [ 0
] ; _rtB -> an2wnfuhuf [ 0 ] = _rtB -> iosmpahw4l ; _rtB -> an2wnfuhuf [ 1 ]
= 0.0 ; _rtB -> an2wnfuhuf [ 2 ] = 0.0 ; _rtDW -> cfcxzdmnh2 [ 0 ] = ! ( _rtB
-> an2wnfuhuf [ 0 ] == _rtDW -> cfcxzdmnh2 [ 1 ] ) ; _rtDW -> cfcxzdmnh2 [ 1
] = _rtB -> an2wnfuhuf [ 0 ] ; _rtB -> an2wnfuhuf [ 3 ] = _rtDW -> cfcxzdmnh2
[ 0 ] ; _rtB -> fmgwumzgxb [ 0 ] = _rtB -> cbfxt52wbm ; _rtB -> fmgwumzgxb [
1 ] = 0.0 ; _rtB -> fmgwumzgxb [ 2 ] = 0.0 ; _rtDW -> a00znb3en0 [ 0 ] = ! (
_rtB -> fmgwumzgxb [ 0 ] == _rtDW -> a00znb3en0 [ 1 ] ) ; _rtDW -> a00znb3en0
[ 1 ] = _rtB -> fmgwumzgxb [ 0 ] ; _rtB -> fmgwumzgxb [ 3 ] = _rtDW ->
a00znb3en0 [ 0 ] ; _rtB -> jtt04ldhjt [ 0 ] = _rtB -> cw4z5gywbm ; _rtB ->
jtt04ldhjt [ 1 ] = 0.0 ; _rtB -> jtt04ldhjt [ 2 ] = 0.0 ; _rtDW -> gcy2ig3q0h
[ 0 ] = ! ( _rtB -> jtt04ldhjt [ 0 ] == _rtDW -> gcy2ig3q0h [ 1 ] ) ; _rtDW
-> gcy2ig3q0h [ 1 ] = _rtB -> jtt04ldhjt [ 0 ] ; _rtB -> jtt04ldhjt [ 3 ] =
_rtDW -> gcy2ig3q0h [ 0 ] ; _rtB -> msjqvapfuz [ 0 ] = _rtB -> m1np00f0rm ;
_rtB -> msjqvapfuz [ 1 ] = 0.0 ; _rtB -> msjqvapfuz [ 2 ] = 0.0 ; _rtDW ->
jlrzfpwzgv [ 0 ] = ! ( _rtB -> msjqvapfuz [ 0 ] == _rtDW -> jlrzfpwzgv [ 1 ]
) ; _rtDW -> jlrzfpwzgv [ 1 ] = _rtB -> msjqvapfuz [ 0 ] ; _rtB -> msjqvapfuz
[ 3 ] = _rtDW -> jlrzfpwzgv [ 0 ] ; _rtB -> eu4ri0qcpw [ 0 ] = _rtB ->
norx5co1uv ; _rtB -> eu4ri0qcpw [ 1 ] = 0.0 ; _rtB -> eu4ri0qcpw [ 2 ] = 0.0
; _rtDW -> jw1mh0ghyd [ 0 ] = ! ( _rtB -> eu4ri0qcpw [ 0 ] == _rtDW ->
jw1mh0ghyd [ 1 ] ) ; _rtDW -> jw1mh0ghyd [ 1 ] = _rtB -> eu4ri0qcpw [ 0 ] ;
_rtB -> eu4ri0qcpw [ 3 ] = _rtDW -> jw1mh0ghyd [ 0 ] ; _rtB -> oo2fmt3syw [ 0
] = _rtB -> bnzivjdbfm ; _rtB -> oo2fmt3syw [ 1 ] = 0.0 ; _rtB -> oo2fmt3syw
[ 2 ] = 0.0 ; _rtDW -> atq4utflo0 [ 0 ] = ! ( _rtB -> oo2fmt3syw [ 0 ] ==
_rtDW -> atq4utflo0 [ 1 ] ) ; _rtDW -> atq4utflo0 [ 1 ] = _rtB -> oo2fmt3syw
[ 0 ] ; _rtB -> oo2fmt3syw [ 3 ] = _rtDW -> atq4utflo0 [ 0 ] ; _rtB ->
cqi5uoc0d5 [ 0 ] = _rtB -> i4jzjvmrxm ; _rtB -> cqi5uoc0d5 [ 1 ] = 0.0 ; _rtB
-> cqi5uoc0d5 [ 2 ] = 0.0 ; _rtDW -> docwm3v1g1 [ 0 ] = ! ( _rtB ->
cqi5uoc0d5 [ 0 ] == _rtDW -> docwm3v1g1 [ 1 ] ) ; _rtDW -> docwm3v1g1 [ 1 ] =
_rtB -> cqi5uoc0d5 [ 0 ] ; _rtB -> cqi5uoc0d5 [ 3 ] = _rtDW -> docwm3v1g1 [ 0
] ; _rtB -> kjwb5waanz [ 0 ] = _rtB -> dzivky0xvk ; _rtB -> kjwb5waanz [ 1 ]
= 0.0 ; _rtB -> kjwb5waanz [ 2 ] = 0.0 ; _rtDW -> g5gcevl3mz [ 0 ] = ! ( _rtB
-> kjwb5waanz [ 0 ] == _rtDW -> g5gcevl3mz [ 1 ] ) ; _rtDW -> g5gcevl3mz [ 1
] = _rtB -> kjwb5waanz [ 0 ] ; _rtB -> kjwb5waanz [ 3 ] = _rtDW -> g5gcevl3mz
[ 0 ] ; _rtB -> mxm25rbgqo [ 0 ] = _rtB -> mintffkybm ; _rtB -> mxm25rbgqo [
1 ] = 0.0 ; _rtB -> mxm25rbgqo [ 2 ] = 0.0 ; _rtDW -> kgqk2zk000 [ 0 ] = ! (
_rtB -> mxm25rbgqo [ 0 ] == _rtDW -> kgqk2zk000 [ 1 ] ) ; _rtDW -> kgqk2zk000
[ 1 ] = _rtB -> mxm25rbgqo [ 0 ] ; _rtB -> mxm25rbgqo [ 3 ] = _rtDW ->
kgqk2zk000 [ 0 ] ; _rtB -> ojleizhdtr [ 0 ] = _rtB -> iba4x5je4e ; _rtB ->
ojleizhdtr [ 1 ] = 0.0 ; _rtB -> ojleizhdtr [ 2 ] = 0.0 ; _rtDW -> mgtjce2po2
[ 0 ] = ! ( _rtB -> ojleizhdtr [ 0 ] == _rtDW -> mgtjce2po2 [ 1 ] ) ; _rtDW
-> mgtjce2po2 [ 1 ] = _rtB -> ojleizhdtr [ 0 ] ; _rtB -> ojleizhdtr [ 3 ] =
_rtDW -> mgtjce2po2 [ 0 ] ; _rtB -> e2ky3si0z5 [ 0 ] = _rtB -> hghymxjfpw ;
_rtB -> e2ky3si0z5 [ 1 ] = 0.0 ; _rtB -> e2ky3si0z5 [ 2 ] = 0.0 ; _rtDW ->
hubt2hdojn [ 0 ] = ! ( _rtB -> e2ky3si0z5 [ 0 ] == _rtDW -> hubt2hdojn [ 1 ]
) ; _rtDW -> hubt2hdojn [ 1 ] = _rtB -> e2ky3si0z5 [ 0 ] ; _rtB -> e2ky3si0z5
[ 3 ] = _rtDW -> hubt2hdojn [ 0 ] ; _rtB -> b3gkmz3z13 [ 0 ] = _rtB ->
obrtevmtzo ; _rtB -> b3gkmz3z13 [ 1 ] = 0.0 ; _rtB -> b3gkmz3z13 [ 2 ] = 0.0
; _rtDW -> nuigpfa44w [ 0 ] = ! ( _rtB -> b3gkmz3z13 [ 0 ] == _rtDW ->
nuigpfa44w [ 1 ] ) ; _rtDW -> nuigpfa44w [ 1 ] = _rtB -> b3gkmz3z13 [ 0 ] ;
_rtB -> b3gkmz3z13 [ 3 ] = _rtDW -> nuigpfa44w [ 0 ] ; _rtB -> gskcbakb0n [ 0
] = _rtB -> coz4setksu ; _rtB -> gskcbakb0n [ 1 ] = 0.0 ; _rtB -> gskcbakb0n
[ 2 ] = 0.0 ; _rtDW -> jqo1bwlhzk [ 0 ] = ! ( _rtB -> gskcbakb0n [ 0 ] ==
_rtDW -> jqo1bwlhzk [ 1 ] ) ; _rtDW -> jqo1bwlhzk [ 1 ] = _rtB -> gskcbakb0n
[ 0 ] ; _rtB -> gskcbakb0n [ 3 ] = _rtDW -> jqo1bwlhzk [ 0 ] ; _rtB ->
opqeiinnhh [ 0 ] = _rtB -> g0cphmx0qa ; _rtB -> opqeiinnhh [ 1 ] = 0.0 ; _rtB
-> opqeiinnhh [ 2 ] = 0.0 ; _rtDW -> epambztdgz [ 0 ] = ! ( _rtB ->
opqeiinnhh [ 0 ] == _rtDW -> epambztdgz [ 1 ] ) ; _rtDW -> epambztdgz [ 1 ] =
_rtB -> opqeiinnhh [ 0 ] ; _rtB -> opqeiinnhh [ 3 ] = _rtDW -> epambztdgz [ 0
] ; _rtB -> dux0btem5z [ 0 ] = _rtB -> iax02bnf3g ; _rtB -> dux0btem5z [ 1 ]
= 0.0 ; _rtB -> dux0btem5z [ 2 ] = 0.0 ; _rtDW -> lix3mawqw4 [ 0 ] = ! ( _rtB
-> dux0btem5z [ 0 ] == _rtDW -> lix3mawqw4 [ 1 ] ) ; _rtDW -> lix3mawqw4 [ 1
] = _rtB -> dux0btem5z [ 0 ] ; _rtB -> dux0btem5z [ 3 ] = _rtDW -> lix3mawqw4
[ 0 ] ; _rtB -> gx4xl0g13x [ 0 ] = _rtB -> o1vwpqie15 ; _rtB -> gx4xl0g13x [
1 ] = 0.0 ; _rtB -> gx4xl0g13x [ 2 ] = 0.0 ; _rtDW -> ot3fcdpfj5 [ 0 ] = ! (
_rtB -> gx4xl0g13x [ 0 ] == _rtDW -> ot3fcdpfj5 [ 1 ] ) ; _rtDW -> ot3fcdpfj5
[ 1 ] = _rtB -> gx4xl0g13x [ 0 ] ; _rtB -> gx4xl0g13x [ 3 ] = _rtDW ->
ot3fcdpfj5 [ 0 ] ; _rtB -> ms1rjzdt5w [ 0 ] = _rtB -> hn1b53l2n0 ; _rtB ->
ms1rjzdt5w [ 1 ] = 0.0 ; _rtB -> ms1rjzdt5w [ 2 ] = 0.0 ; _rtDW -> p1s3cvkwlp
[ 0 ] = ! ( _rtB -> ms1rjzdt5w [ 0 ] == _rtDW -> p1s3cvkwlp [ 1 ] ) ; _rtDW
-> p1s3cvkwlp [ 1 ] = _rtB -> ms1rjzdt5w [ 0 ] ; _rtB -> ms1rjzdt5w [ 3 ] =
_rtDW -> p1s3cvkwlp [ 0 ] ; _rtB -> mux3lmezpo [ 0 ] = _rtB -> k25dprgkln ;
_rtB -> mux3lmezpo [ 1 ] = 0.0 ; _rtB -> mux3lmezpo [ 2 ] = 0.0 ; _rtDW ->
in1mweemwr [ 0 ] = ! ( _rtB -> mux3lmezpo [ 0 ] == _rtDW -> in1mweemwr [ 1 ]
) ; _rtDW -> in1mweemwr [ 1 ] = _rtB -> mux3lmezpo [ 0 ] ; _rtB -> mux3lmezpo
[ 3 ] = _rtDW -> in1mweemwr [ 0 ] ; _rtB -> puuegtmd3s [ 0 ] = _rtB ->
fpnpyxwqzv ; _rtB -> puuegtmd3s [ 1 ] = 0.0 ; _rtB -> puuegtmd3s [ 2 ] = 0.0
; _rtDW -> hsugosk3ix [ 0 ] = ! ( _rtB -> puuegtmd3s [ 0 ] == _rtDW ->
hsugosk3ix [ 1 ] ) ; _rtDW -> hsugosk3ix [ 1 ] = _rtB -> puuegtmd3s [ 0 ] ;
_rtB -> puuegtmd3s [ 3 ] = _rtDW -> hsugosk3ix [ 0 ] ; _rtB -> lllrp0aker [ 0
] = _rtB -> ixfoetek2s ; _rtB -> lllrp0aker [ 1 ] = 0.0 ; _rtB -> lllrp0aker
[ 2 ] = 0.0 ; _rtDW -> pre0do34tj [ 0 ] = ! ( _rtB -> lllrp0aker [ 0 ] ==
_rtDW -> pre0do34tj [ 1 ] ) ; _rtDW -> pre0do34tj [ 1 ] = _rtB -> lllrp0aker
[ 0 ] ; _rtB -> lllrp0aker [ 3 ] = _rtDW -> pre0do34tj [ 0 ] ; _rtB ->
fs3cyjgxj5 [ 0 ] = _rtB -> avb0vt1iwo ; _rtB -> fs3cyjgxj5 [ 1 ] = 0.0 ; _rtB
-> fs3cyjgxj5 [ 2 ] = 0.0 ; _rtDW -> azpj2bw1bf [ 0 ] = ! ( _rtB ->
fs3cyjgxj5 [ 0 ] == _rtDW -> azpj2bw1bf [ 1 ] ) ; _rtDW -> azpj2bw1bf [ 1 ] =
_rtB -> fs3cyjgxj5 [ 0 ] ; _rtB -> fs3cyjgxj5 [ 3 ] = _rtDW -> azpj2bw1bf [ 0
] ; _rtB -> eanph2koid [ 0 ] = _rtB -> khybymqqhy ; _rtB -> eanph2koid [ 1 ]
= 0.0 ; _rtB -> eanph2koid [ 2 ] = 0.0 ; _rtDW -> gwqiluddz4 [ 0 ] = ! ( _rtB
-> eanph2koid [ 0 ] == _rtDW -> gwqiluddz4 [ 1 ] ) ; _rtDW -> gwqiluddz4 [ 1
] = _rtB -> eanph2koid [ 0 ] ; _rtB -> eanph2koid [ 3 ] = _rtDW -> gwqiluddz4
[ 0 ] ; _rtB -> kl3mthx5kg [ 0 ] = _rtB -> hciuzqgofc ; _rtB -> kl3mthx5kg [
1 ] = 0.0 ; _rtB -> kl3mthx5kg [ 2 ] = 0.0 ; _rtDW -> m1ihbvn01p [ 0 ] = ! (
_rtB -> kl3mthx5kg [ 0 ] == _rtDW -> m1ihbvn01p [ 1 ] ) ; _rtDW -> m1ihbvn01p
[ 1 ] = _rtB -> kl3mthx5kg [ 0 ] ; _rtB -> kl3mthx5kg [ 3 ] = _rtDW ->
m1ihbvn01p [ 0 ] ; _rtB -> o5gchjnt0x [ 0 ] = _rtB -> e5ai05cmru ; _rtB ->
o5gchjnt0x [ 1 ] = 0.0 ; _rtB -> o5gchjnt0x [ 2 ] = 0.0 ; _rtDW -> jm0e5r30uv
[ 0 ] = ! ( _rtB -> o5gchjnt0x [ 0 ] == _rtDW -> jm0e5r30uv [ 1 ] ) ; _rtDW
-> jm0e5r30uv [ 1 ] = _rtB -> o5gchjnt0x [ 0 ] ; _rtB -> o5gchjnt0x [ 3 ] =
_rtDW -> jm0e5r30uv [ 0 ] ; for ( i = 0 ; i < 8 ; i ++ ) { lnrpexhl3s [ i ] .
re = _rtP -> P_58 * _rtB -> f43lvtvllj [ i ] . re ; lnrpexhl3s [ i ] . im =
_rtP -> P_58 * _rtB -> f43lvtvllj [ i ] . im ; } _rtB -> ickakrpg51 = _rtP ->
P_59 * lnrpexhl3s [ 1 ] . re ; _rtB -> a33iwdkpc0 = _rtP -> P_59 * lnrpexhl3s
[ 1 ] . im ; _rtB -> gcznq22lqz [ 0 ] = _rtB -> ickakrpg51 ; _rtB ->
gcznq22lqz [ 1 ] = 0.0 ; _rtB -> gcznq22lqz [ 2 ] = 0.0 ; _rtDW -> lfjob2ip4p
[ 0 ] = ! ( _rtB -> gcznq22lqz [ 0 ] == _rtDW -> lfjob2ip4p [ 1 ] ) ; _rtDW
-> lfjob2ip4p [ 1 ] = _rtB -> gcznq22lqz [ 0 ] ; _rtB -> gcznq22lqz [ 3 ] =
_rtDW -> lfjob2ip4p [ 0 ] ; _rtB -> msnmn2oqo1 [ 0 ] = _rtB -> a33iwdkpc0 ;
_rtB -> msnmn2oqo1 [ 1 ] = 0.0 ; _rtB -> msnmn2oqo1 [ 2 ] = 0.0 ; _rtDW ->
fdocnwslws [ 0 ] = ! ( _rtB -> msnmn2oqo1 [ 0 ] == _rtDW -> fdocnwslws [ 1 ]
) ; _rtDW -> fdocnwslws [ 1 ] = _rtB -> msnmn2oqo1 [ 0 ] ; _rtB -> msnmn2oqo1
[ 3 ] = _rtDW -> fdocnwslws [ 0 ] ; _rtB -> gez2k1sumn [ 0 ] = _rtB ->
gqem11lfl1 ; _rtB -> gez2k1sumn [ 1 ] = 0.0 ; _rtB -> gez2k1sumn [ 2 ] = 0.0
; _rtDW -> bujncgvbzy [ 0 ] = ! ( _rtB -> gez2k1sumn [ 0 ] == _rtDW ->
bujncgvbzy [ 1 ] ) ; _rtDW -> bujncgvbzy [ 1 ] = _rtB -> gez2k1sumn [ 0 ] ;
_rtB -> gez2k1sumn [ 3 ] = _rtDW -> bujncgvbzy [ 0 ] ; _rtB -> pjkwipetws =
_rtP -> P_61 * lnrpexhl3s [ 2 ] . re ; _rtB -> ob4z0xroqs = _rtP -> P_61 *
lnrpexhl3s [ 2 ] . im ; _rtB -> fpi1fudjdx [ 0 ] = _rtB -> pjkwipetws ; _rtB
-> fpi1fudjdx [ 1 ] = 0.0 ; _rtB -> fpi1fudjdx [ 2 ] = 0.0 ; _rtDW ->
dmwm5s41zk [ 0 ] = ! ( _rtB -> fpi1fudjdx [ 0 ] == _rtDW -> dmwm5s41zk [ 1 ]
) ; _rtDW -> dmwm5s41zk [ 1 ] = _rtB -> fpi1fudjdx [ 0 ] ; _rtB -> fpi1fudjdx
[ 3 ] = _rtDW -> dmwm5s41zk [ 0 ] ; _rtB -> m32c44h0ep [ 0 ] = _rtB ->
ob4z0xroqs ; _rtB -> m32c44h0ep [ 1 ] = 0.0 ; _rtB -> m32c44h0ep [ 2 ] = 0.0
; _rtDW -> nraexau03d [ 0 ] = ! ( _rtB -> m32c44h0ep [ 0 ] == _rtDW ->
nraexau03d [ 1 ] ) ; _rtDW -> nraexau03d [ 1 ] = _rtB -> m32c44h0ep [ 0 ] ;
_rtB -> m32c44h0ep [ 3 ] = _rtDW -> nraexau03d [ 0 ] ; _rtB -> lf31z0tpif [ 0
] = _rtB -> ij5smlnheg ; _rtB -> lf31z0tpif [ 1 ] = 0.0 ; _rtB -> lf31z0tpif
[ 2 ] = 0.0 ; _rtDW -> awcuc3ivj4 [ 0 ] = ! ( _rtB -> lf31z0tpif [ 0 ] ==
_rtDW -> awcuc3ivj4 [ 1 ] ) ; _rtDW -> awcuc3ivj4 [ 1 ] = _rtB -> lf31z0tpif
[ 0 ] ; _rtB -> lf31z0tpif [ 3 ] = _rtDW -> awcuc3ivj4 [ 0 ] ; _rtB ->
c12fo2wuap = _rtP -> P_63 * lnrpexhl3s [ 3 ] . re ; _rtB -> fippa5fbqm = _rtP
-> P_63 * lnrpexhl3s [ 3 ] . im ; _rtB -> kum3yghgpu [ 0 ] = _rtB ->
c12fo2wuap ; _rtB -> kum3yghgpu [ 1 ] = 0.0 ; _rtB -> kum3yghgpu [ 2 ] = 0.0
; _rtDW -> klufc3ir4p [ 0 ] = ! ( _rtB -> kum3yghgpu [ 0 ] == _rtDW ->
klufc3ir4p [ 1 ] ) ; _rtDW -> klufc3ir4p [ 1 ] = _rtB -> kum3yghgpu [ 0 ] ;
_rtB -> kum3yghgpu [ 3 ] = _rtDW -> klufc3ir4p [ 0 ] ; _rtB -> j0frnxgtyr [ 0
] = _rtB -> fippa5fbqm ; _rtB -> j0frnxgtyr [ 1 ] = 0.0 ; _rtB -> j0frnxgtyr
[ 2 ] = 0.0 ; _rtDW -> na2grfynxa [ 0 ] = ! ( _rtB -> j0frnxgtyr [ 0 ] ==
_rtDW -> na2grfynxa [ 1 ] ) ; _rtDW -> na2grfynxa [ 1 ] = _rtB -> j0frnxgtyr
[ 0 ] ; _rtB -> j0frnxgtyr [ 3 ] = _rtDW -> na2grfynxa [ 0 ] ; _rtB ->
nrx21rgk2y [ 0 ] = _rtB -> gamnm4smcq ; _rtB -> nrx21rgk2y [ 1 ] = 0.0 ; _rtB
-> nrx21rgk2y [ 2 ] = 0.0 ; _rtDW -> lmn533mop5 [ 0 ] = ! ( _rtB ->
nrx21rgk2y [ 0 ] == _rtDW -> lmn533mop5 [ 1 ] ) ; _rtDW -> lmn533mop5 [ 1 ] =
_rtB -> nrx21rgk2y [ 0 ] ; _rtB -> nrx21rgk2y [ 3 ] = _rtDW -> lmn533mop5 [ 0
] ; _rtB -> e4xhzfouux = _rtP -> P_65 * lnrpexhl3s [ 4 ] . re ; _rtB ->
b5zfknddcd = _rtP -> P_65 * lnrpexhl3s [ 4 ] . im ; _rtB -> nx5lw1hrpd [ 0 ]
= _rtB -> e4xhzfouux ; _rtB -> nx5lw1hrpd [ 1 ] = 0.0 ; _rtB -> nx5lw1hrpd [
2 ] = 0.0 ; _rtDW -> lnopnl3sy4 [ 0 ] = ! ( _rtB -> nx5lw1hrpd [ 0 ] == _rtDW
-> lnopnl3sy4 [ 1 ] ) ; _rtDW -> lnopnl3sy4 [ 1 ] = _rtB -> nx5lw1hrpd [ 0 ]
; _rtB -> nx5lw1hrpd [ 3 ] = _rtDW -> lnopnl3sy4 [ 0 ] ; _rtB -> gzrokej5wm [
0 ] = _rtB -> b5zfknddcd ; _rtB -> gzrokej5wm [ 1 ] = 0.0 ; _rtB ->
gzrokej5wm [ 2 ] = 0.0 ; _rtDW -> bkltpwtbhq [ 0 ] = ! ( _rtB -> gzrokej5wm [
0 ] == _rtDW -> bkltpwtbhq [ 1 ] ) ; _rtDW -> bkltpwtbhq [ 1 ] = _rtB ->
gzrokej5wm [ 0 ] ; _rtB -> gzrokej5wm [ 3 ] = _rtDW -> bkltpwtbhq [ 0 ] ;
_rtB -> p3k225o05f [ 0 ] = _rtB -> lg2zrguxmj ; _rtB -> p3k225o05f [ 1 ] =
0.0 ; _rtB -> p3k225o05f [ 2 ] = 0.0 ; _rtDW -> pukqzoofl4 [ 0 ] = ! ( _rtB
-> p3k225o05f [ 0 ] == _rtDW -> pukqzoofl4 [ 1 ] ) ; _rtDW -> pukqzoofl4 [ 1
] = _rtB -> p3k225o05f [ 0 ] ; _rtB -> p3k225o05f [ 3 ] = _rtDW -> pukqzoofl4
[ 0 ] ; _rtB -> nxfkmpdnmb = _rtP -> P_67 * lnrpexhl3s [ 5 ] . re ; _rtB ->
hmgqua5yup = _rtP -> P_67 * lnrpexhl3s [ 5 ] . im ; _rtB -> ha5ysd3nkd [ 0 ]
= _rtB -> nxfkmpdnmb ; _rtB -> ha5ysd3nkd [ 1 ] = 0.0 ; _rtB -> ha5ysd3nkd [
2 ] = 0.0 ; _rtDW -> f0tm1tk1z2 [ 0 ] = ! ( _rtB -> ha5ysd3nkd [ 0 ] == _rtDW
-> f0tm1tk1z2 [ 1 ] ) ; _rtDW -> f0tm1tk1z2 [ 1 ] = _rtB -> ha5ysd3nkd [ 0 ]
; _rtB -> ha5ysd3nkd [ 3 ] = _rtDW -> f0tm1tk1z2 [ 0 ] ; _rtB -> mgyhsilw3s [
0 ] = _rtB -> hmgqua5yup ; _rtB -> mgyhsilw3s [ 1 ] = 0.0 ; _rtB ->
mgyhsilw3s [ 2 ] = 0.0 ; _rtDW -> n4uualil3m [ 0 ] = ! ( _rtB -> mgyhsilw3s [
0 ] == _rtDW -> n4uualil3m [ 1 ] ) ; _rtDW -> n4uualil3m [ 1 ] = _rtB ->
mgyhsilw3s [ 0 ] ; _rtB -> mgyhsilw3s [ 3 ] = _rtDW -> n4uualil3m [ 0 ] ;
_rtB -> if205naixu [ 0 ] = _rtB -> jjmaoeqpof ; _rtB -> if205naixu [ 1 ] =
0.0 ; _rtB -> if205naixu [ 2 ] = 0.0 ; _rtDW -> pgdoxewvw5 [ 0 ] = ! ( _rtB
-> if205naixu [ 0 ] == _rtDW -> pgdoxewvw5 [ 1 ] ) ; _rtDW -> pgdoxewvw5 [ 1
] = _rtB -> if205naixu [ 0 ] ; _rtB -> if205naixu [ 3 ] = _rtDW -> pgdoxewvw5
[ 0 ] ; _rtB -> badnubrbn0 = _rtP -> P_69 * lnrpexhl3s [ 0 ] . re ; _rtB ->
m4r5hgmq10 = _rtP -> P_69 * lnrpexhl3s [ 0 ] . im ; _rtB -> n5qvk5awq2 [ 0 ]
= _rtB -> badnubrbn0 ; _rtB -> n5qvk5awq2 [ 1 ] = 0.0 ; _rtB -> n5qvk5awq2 [
2 ] = 0.0 ; _rtDW -> omi5xbxozs [ 0 ] = ! ( _rtB -> n5qvk5awq2 [ 0 ] == _rtDW
-> omi5xbxozs [ 1 ] ) ; _rtDW -> omi5xbxozs [ 1 ] = _rtB -> n5qvk5awq2 [ 0 ]
; _rtB -> n5qvk5awq2 [ 3 ] = _rtDW -> omi5xbxozs [ 0 ] ; _rtB -> gonjhpldiw [
0 ] = _rtB -> m4r5hgmq10 ; _rtB -> gonjhpldiw [ 1 ] = 0.0 ; _rtB ->
gonjhpldiw [ 2 ] = 0.0 ; _rtDW -> p5yknneauj [ 0 ] = ! ( _rtB -> gonjhpldiw [
0 ] == _rtDW -> p5yknneauj [ 1 ] ) ; _rtDW -> p5yknneauj [ 1 ] = _rtB ->
gonjhpldiw [ 0 ] ; _rtB -> gonjhpldiw [ 3 ] = _rtDW -> p5yknneauj [ 0 ] ;
_rtB -> clulznxw1n [ 0 ] = _rtB -> g25qkuykb5 ; _rtB -> clulznxw1n [ 1 ] =
0.0 ; _rtB -> clulznxw1n [ 2 ] = 0.0 ; _rtDW -> bglce4eedg [ 0 ] = ! ( _rtB
-> clulznxw1n [ 0 ] == _rtDW -> bglce4eedg [ 1 ] ) ; _rtDW -> bglce4eedg [ 1
] = _rtB -> clulznxw1n [ 0 ] ; _rtB -> clulznxw1n [ 3 ] = _rtDW -> bglce4eedg
[ 0 ] ; _rtB -> f0lquhrjye = _rtP -> P_71 * lnrpexhl3s [ 6 ] . re ; _rtB ->
hexfssuwqh = _rtP -> P_71 * lnrpexhl3s [ 6 ] . im ; _rtB -> bmn3wm3a03 [ 0 ]
= _rtB -> f0lquhrjye ; _rtB -> bmn3wm3a03 [ 1 ] = 0.0 ; _rtB -> bmn3wm3a03 [
2 ] = 0.0 ; _rtDW -> msz4vl3nnz [ 0 ] = ! ( _rtB -> bmn3wm3a03 [ 0 ] == _rtDW
-> msz4vl3nnz [ 1 ] ) ; _rtDW -> msz4vl3nnz [ 1 ] = _rtB -> bmn3wm3a03 [ 0 ]
; _rtB -> bmn3wm3a03 [ 3 ] = _rtDW -> msz4vl3nnz [ 0 ] ; _rtB -> huzjrbabya [
0 ] = _rtB -> hexfssuwqh ; _rtB -> huzjrbabya [ 1 ] = 0.0 ; _rtB ->
huzjrbabya [ 2 ] = 0.0 ; _rtDW -> hz1al1s5x0 [ 0 ] = ! ( _rtB -> huzjrbabya [
0 ] == _rtDW -> hz1al1s5x0 [ 1 ] ) ; _rtDW -> hz1al1s5x0 [ 1 ] = _rtB ->
huzjrbabya [ 0 ] ; _rtB -> huzjrbabya [ 3 ] = _rtDW -> hz1al1s5x0 [ 0 ] ;
_rtB -> ic3ayvi1bw [ 0 ] = _rtB -> osfil5rax0 ; _rtB -> ic3ayvi1bw [ 1 ] =
0.0 ; _rtB -> ic3ayvi1bw [ 2 ] = 0.0 ; _rtDW -> cyutqo4y04 [ 0 ] = ! ( _rtB
-> ic3ayvi1bw [ 0 ] == _rtDW -> cyutqo4y04 [ 1 ] ) ; _rtDW -> cyutqo4y04 [ 1
] = _rtB -> ic3ayvi1bw [ 0 ] ; _rtB -> ic3ayvi1bw [ 3 ] = _rtDW -> cyutqo4y04
[ 0 ] ; _rtB -> jexna1namy = _rtP -> P_73 * lnrpexhl3s [ 7 ] . re ; _rtB ->
egofrhfebv = _rtP -> P_73 * lnrpexhl3s [ 7 ] . im ; _rtB -> cztsnzv4ud [ 0 ]
= _rtB -> jexna1namy ; _rtB -> cztsnzv4ud [ 1 ] = 0.0 ; _rtB -> cztsnzv4ud [
2 ] = 0.0 ; _rtDW -> dkq1rxqa03 [ 0 ] = ! ( _rtB -> cztsnzv4ud [ 0 ] == _rtDW
-> dkq1rxqa03 [ 1 ] ) ; _rtDW -> dkq1rxqa03 [ 1 ] = _rtB -> cztsnzv4ud [ 0 ]
; _rtB -> cztsnzv4ud [ 3 ] = _rtDW -> dkq1rxqa03 [ 0 ] ; _rtB -> mur3qdwolm [
0 ] = _rtB -> egofrhfebv ; _rtB -> mur3qdwolm [ 1 ] = 0.0 ; _rtB ->
mur3qdwolm [ 2 ] = 0.0 ; _rtDW -> pwcsb4uz5e [ 0 ] = ! ( _rtB -> mur3qdwolm [
0 ] == _rtDW -> pwcsb4uz5e [ 1 ] ) ; _rtDW -> pwcsb4uz5e [ 1 ] = _rtB ->
mur3qdwolm [ 0 ] ; _rtB -> mur3qdwolm [ 3 ] = _rtDW -> pwcsb4uz5e [ 0 ] ;
_rtB -> e0ix30svhl [ 0 ] = _rtB -> o1fq40bg4g ; _rtB -> e0ix30svhl [ 1 ] =
0.0 ; _rtB -> e0ix30svhl [ 2 ] = 0.0 ; _rtDW -> dkp3owmvdh [ 0 ] = ! ( _rtB
-> e0ix30svhl [ 0 ] == _rtDW -> dkp3owmvdh [ 1 ] ) ; _rtDW -> dkp3owmvdh [ 1
] = _rtB -> e0ix30svhl [ 0 ] ; _rtB -> e0ix30svhl [ 3 ] = _rtDW -> dkp3owmvdh
[ 0 ] ; _rtB -> b3s3ztpdtw [ 0 ] = _rtB -> e4lj2wbbad ; _rtB -> b3s3ztpdtw [
1 ] = 0.0 ; _rtB -> b3s3ztpdtw [ 2 ] = 0.0 ; _rtDW -> nxjr5loxj5 [ 0 ] = ! (
_rtB -> b3s3ztpdtw [ 0 ] == _rtDW -> nxjr5loxj5 [ 1 ] ) ; _rtDW -> nxjr5loxj5
[ 1 ] = _rtB -> b3s3ztpdtw [ 0 ] ; _rtB -> b3s3ztpdtw [ 3 ] = _rtDW ->
nxjr5loxj5 [ 0 ] ; _rtB -> epvii2yd3g [ 0 ] = _rtB -> i5cflooyjb ; _rtB ->
epvii2yd3g [ 1 ] = 0.0 ; _rtB -> epvii2yd3g [ 2 ] = 0.0 ; _rtDW -> e0njklelyl
[ 0 ] = ! ( _rtB -> epvii2yd3g [ 0 ] == _rtDW -> e0njklelyl [ 1 ] ) ; _rtDW
-> e0njklelyl [ 1 ] = _rtB -> epvii2yd3g [ 0 ] ; _rtB -> epvii2yd3g [ 3 ] =
_rtDW -> e0njklelyl [ 0 ] ; _rtB -> g1l3u2juak [ 0 ] = _rtB -> aqi1emzk3x ;
_rtB -> g1l3u2juak [ 1 ] = 0.0 ; _rtB -> g1l3u2juak [ 2 ] = 0.0 ; _rtDW ->
knrv0p4sqs [ 0 ] = ! ( _rtB -> g1l3u2juak [ 0 ] == _rtDW -> knrv0p4sqs [ 1 ]
) ; _rtDW -> knrv0p4sqs [ 1 ] = _rtB -> g1l3u2juak [ 0 ] ; _rtB -> g1l3u2juak
[ 3 ] = _rtDW -> knrv0p4sqs [ 0 ] ; _rtB -> kmjfslwmp0 [ 0 ] = _rtB ->
poez10vfbl ; _rtB -> kmjfslwmp0 [ 1 ] = 0.0 ; _rtB -> kmjfslwmp0 [ 2 ] = 0.0
; _rtDW -> cs3tx1cyuy [ 0 ] = ! ( _rtB -> kmjfslwmp0 [ 0 ] == _rtDW ->
cs3tx1cyuy [ 1 ] ) ; _rtDW -> cs3tx1cyuy [ 1 ] = _rtB -> kmjfslwmp0 [ 0 ] ;
_rtB -> kmjfslwmp0 [ 3 ] = _rtDW -> cs3tx1cyuy [ 0 ] ; _rtB -> g1f5yabwsg [ 0
] = _rtB -> mtmyhj0pya ; _rtB -> g1f5yabwsg [ 1 ] = 0.0 ; _rtB -> g1f5yabwsg
[ 2 ] = 0.0 ; _rtDW -> hvmetv1gfv [ 0 ] = ! ( _rtB -> g1f5yabwsg [ 0 ] ==
_rtDW -> hvmetv1gfv [ 1 ] ) ; _rtDW -> hvmetv1gfv [ 1 ] = _rtB -> g1f5yabwsg
[ 0 ] ; _rtB -> g1f5yabwsg [ 3 ] = _rtDW -> hvmetv1gfv [ 0 ] ; _rtB ->
hw2mmpu35u [ 0 ] = _rtB -> drel0c0vue ; _rtB -> hw2mmpu35u [ 1 ] = 0.0 ; _rtB
-> hw2mmpu35u [ 2 ] = 0.0 ; _rtDW -> fg1xeyhvkx [ 0 ] = ! ( _rtB ->
hw2mmpu35u [ 0 ] == _rtDW -> fg1xeyhvkx [ 1 ] ) ; _rtDW -> fg1xeyhvkx [ 1 ] =
_rtB -> hw2mmpu35u [ 0 ] ; _rtB -> hw2mmpu35u [ 3 ] = _rtDW -> fg1xeyhvkx [ 0
] ; _rtB -> cpcc4ejnan [ 0 ] = _rtB -> a3htuh3v0z ; _rtB -> cpcc4ejnan [ 1 ]
= 0.0 ; _rtB -> cpcc4ejnan [ 2 ] = 0.0 ; _rtDW -> po2gh2bkgx [ 0 ] = ! ( _rtB
-> cpcc4ejnan [ 0 ] == _rtDW -> po2gh2bkgx [ 1 ] ) ; _rtDW -> po2gh2bkgx [ 1
] = _rtB -> cpcc4ejnan [ 0 ] ; _rtB -> cpcc4ejnan [ 3 ] = _rtDW -> po2gh2bkgx
[ 0 ] ; _rtB -> lq0ucqb2yr [ 0 ] = _rtB -> nmccgjqply ; _rtB -> lq0ucqb2yr [
1 ] = 0.0 ; _rtB -> lq0ucqb2yr [ 2 ] = 0.0 ; _rtDW -> ihbdhthj51 [ 0 ] = ! (
_rtB -> lq0ucqb2yr [ 0 ] == _rtDW -> ihbdhthj51 [ 1 ] ) ; _rtDW -> ihbdhthj51
[ 1 ] = _rtB -> lq0ucqb2yr [ 0 ] ; _rtB -> lq0ucqb2yr [ 3 ] = _rtDW ->
ihbdhthj51 [ 0 ] ; ssCallAccelRunBlock ( S , 7 , 174 , SS_CALL_MDL_OUTPUTS )
; ssCallAccelRunBlock ( S , 7 , 175 , SS_CALL_MDL_OUTPUTS ) ; alixvjqnkb =
muDoubleScalarRound ( _rtP -> P_83 * _rtB -> dt2p30n3iu [ 0 ] / _rtP -> P_84
) * _rtP -> P_84 ; if ( alixvjqnkb > _rtP -> P_85 ) { mnbn5mepwj [ 0 ] . re =
_rtP -> P_85 ; } else if ( alixvjqnkb < _rtP -> P_86 ) { mnbn5mepwj [ 0 ] .
re = _rtP -> P_86 ; } else { mnbn5mepwj [ 0 ] . re = alixvjqnkb ; }
alixvjqnkb = muDoubleScalarRound ( _rtP -> P_83 * _rtB -> dt2p30n3iu [ 1 ] /
_rtP -> P_87 ) * _rtP -> P_87 ; if ( alixvjqnkb > _rtP -> P_88 ) { mnbn5mepwj
[ 0 ] . im = _rtP -> P_88 ; } else if ( alixvjqnkb < _rtP -> P_89 ) {
mnbn5mepwj [ 0 ] . im = _rtP -> P_89 ; } else { mnbn5mepwj [ 0 ] . im =
alixvjqnkb ; } alixvjqnkb = muDoubleScalarRound ( _rtP -> P_90 * _rtB ->
dt2p30n3iu [ 2 ] / _rtP -> P_91 ) * _rtP -> P_91 ; if ( alixvjqnkb > _rtP ->
P_92 ) { mnbn5mepwj [ 1 ] . re = _rtP -> P_92 ; } else if ( alixvjqnkb < _rtP
-> P_93 ) { mnbn5mepwj [ 1 ] . re = _rtP -> P_93 ; } else { mnbn5mepwj [ 1 ]
. re = alixvjqnkb ; } alixvjqnkb = muDoubleScalarRound ( _rtP -> P_90 * _rtB
-> dt2p30n3iu [ 3 ] / _rtP -> P_94 ) * _rtP -> P_94 ; if ( alixvjqnkb > _rtP
-> P_95 ) { mnbn5mepwj [ 1 ] . im = _rtP -> P_95 ; } else if ( alixvjqnkb <
_rtP -> P_96 ) { mnbn5mepwj [ 1 ] . im = _rtP -> P_96 ; } else { mnbn5mepwj [
1 ] . im = alixvjqnkb ; } alixvjqnkb = muDoubleScalarRound ( _rtP -> P_97 *
_rtB -> dt2p30n3iu [ 4 ] / _rtP -> P_98 ) * _rtP -> P_98 ; if ( alixvjqnkb >
_rtP -> P_99 ) { mnbn5mepwj [ 2 ] . re = _rtP -> P_99 ; } else if (
alixvjqnkb < _rtP -> P_100 ) { mnbn5mepwj [ 2 ] . re = _rtP -> P_100 ; } else
{ mnbn5mepwj [ 2 ] . re = alixvjqnkb ; } alixvjqnkb = muDoubleScalarRound (
_rtP -> P_97 * _rtB -> dt2p30n3iu [ 5 ] / _rtP -> P_101 ) * _rtP -> P_101 ;
if ( alixvjqnkb > _rtP -> P_102 ) { mnbn5mepwj [ 2 ] . im = _rtP -> P_102 ; }
else if ( alixvjqnkb < _rtP -> P_103 ) { mnbn5mepwj [ 2 ] . im = _rtP ->
P_103 ; } else { mnbn5mepwj [ 2 ] . im = alixvjqnkb ; } alixvjqnkb =
muDoubleScalarRound ( _rtP -> P_104 * _rtB -> dt2p30n3iu [ 6 ] / _rtP ->
P_105 ) * _rtP -> P_105 ; if ( alixvjqnkb > _rtP -> P_106 ) { mnbn5mepwj [ 3
] . re = _rtP -> P_106 ; } else if ( alixvjqnkb < _rtP -> P_107 ) {
mnbn5mepwj [ 3 ] . re = _rtP -> P_107 ; } else { mnbn5mepwj [ 3 ] . re =
alixvjqnkb ; } alixvjqnkb = muDoubleScalarRound ( _rtP -> P_104 * _rtB ->
dt2p30n3iu [ 7 ] / _rtP -> P_108 ) * _rtP -> P_108 ; if ( alixvjqnkb > _rtP
-> P_109 ) { mnbn5mepwj [ 3 ] . im = _rtP -> P_109 ; } else if ( alixvjqnkb <
_rtP -> P_110 ) { mnbn5mepwj [ 3 ] . im = _rtP -> P_110 ; } else { mnbn5mepwj
[ 3 ] . im = alixvjqnkb ; } alixvjqnkb = muDoubleScalarRound ( _rtP -> P_111
* _rtB -> dt2p30n3iu [ 8 ] / _rtP -> P_112 ) * _rtP -> P_112 ; if (
alixvjqnkb > _rtP -> P_113 ) { mnbn5mepwj [ 4 ] . re = _rtP -> P_113 ; } else
if ( alixvjqnkb < _rtP -> P_114 ) { mnbn5mepwj [ 4 ] . re = _rtP -> P_114 ; }
else { mnbn5mepwj [ 4 ] . re = alixvjqnkb ; } alixvjqnkb =
muDoubleScalarRound ( _rtP -> P_111 * _rtB -> dt2p30n3iu [ 9 ] / _rtP ->
P_115 ) * _rtP -> P_115 ; if ( alixvjqnkb > _rtP -> P_116 ) { mnbn5mepwj [ 4
] . im = _rtP -> P_116 ; } else if ( alixvjqnkb < _rtP -> P_117 ) {
mnbn5mepwj [ 4 ] . im = _rtP -> P_117 ; } else { mnbn5mepwj [ 4 ] . im =
alixvjqnkb ; } alixvjqnkb = muDoubleScalarRound ( _rtP -> P_118 * _rtB ->
dt2p30n3iu [ 10 ] / _rtP -> P_119 ) * _rtP -> P_119 ; if ( alixvjqnkb > _rtP
-> P_120 ) { mnbn5mepwj [ 5 ] . re = _rtP -> P_120 ; } else if ( alixvjqnkb <
_rtP -> P_121 ) { mnbn5mepwj [ 5 ] . re = _rtP -> P_121 ; } else { mnbn5mepwj
[ 5 ] . re = alixvjqnkb ; } alixvjqnkb = muDoubleScalarRound ( _rtP -> P_118
* _rtB -> dt2p30n3iu [ 11 ] / _rtP -> P_122 ) * _rtP -> P_122 ; if (
alixvjqnkb > _rtP -> P_123 ) { mnbn5mepwj [ 5 ] . im = _rtP -> P_123 ; } else
if ( alixvjqnkb < _rtP -> P_124 ) { mnbn5mepwj [ 5 ] . im = _rtP -> P_124 ; }
else { mnbn5mepwj [ 5 ] . im = alixvjqnkb ; } alixvjqnkb =
muDoubleScalarRound ( _rtP -> P_125 * _rtB -> dt2p30n3iu [ 12 ] / _rtP ->
P_126 ) * _rtP -> P_126 ; if ( alixvjqnkb > _rtP -> P_127 ) { mnbn5mepwj [ 6
] . re = _rtP -> P_127 ; } else if ( alixvjqnkb < _rtP -> P_128 ) {
mnbn5mepwj [ 6 ] . re = _rtP -> P_128 ; } else { mnbn5mepwj [ 6 ] . re =
alixvjqnkb ; } alixvjqnkb = muDoubleScalarRound ( _rtP -> P_125 * _rtB ->
dt2p30n3iu [ 13 ] / _rtP -> P_129 ) * _rtP -> P_129 ; if ( alixvjqnkb > _rtP
-> P_130 ) { mnbn5mepwj [ 6 ] . im = _rtP -> P_130 ; } else if ( alixvjqnkb <
_rtP -> P_131 ) { mnbn5mepwj [ 6 ] . im = _rtP -> P_131 ; } else { mnbn5mepwj
[ 6 ] . im = alixvjqnkb ; } alixvjqnkb = muDoubleScalarRound ( _rtP -> P_132
* _rtB -> dt2p30n3iu [ 14 ] / _rtP -> P_133 ) * _rtP -> P_133 ; if (
alixvjqnkb > _rtP -> P_134 ) { mnbn5mepwj [ 7 ] . re = _rtP -> P_134 ; } else
if ( alixvjqnkb < _rtP -> P_135 ) { mnbn5mepwj [ 7 ] . re = _rtP -> P_135 ; }
else { mnbn5mepwj [ 7 ] . re = alixvjqnkb ; } alixvjqnkb =
muDoubleScalarRound ( _rtP -> P_132 * _rtB -> dt2p30n3iu [ 15 ] / _rtP ->
P_136 ) * _rtP -> P_136 ; if ( alixvjqnkb > _rtP -> P_137 ) { mnbn5mepwj [ 7
] . im = _rtP -> P_137 ; } else if ( alixvjqnkb < _rtP -> P_138 ) {
mnbn5mepwj [ 7 ] . im = _rtP -> P_138 ; } else { mnbn5mepwj [ 7 ] . im =
alixvjqnkb ; } for ( tapIdx = 0 ; tapIdx < 8 ; tapIdx ++ ) { alixvjqnkb =
6.2831853071795862 * _rtDW -> gpwenu31ap [ tapIdx ] + _rtP -> P_139 ; _rtB ->
cp5wlcdwu2 [ tapIdx ] . re = mnbn5mepwj [ tapIdx ] . re * muDoubleScalarCos (
alixvjqnkb ) - mnbn5mepwj [ tapIdx ] . im * muDoubleScalarSin ( alixvjqnkb )
; _rtB -> cp5wlcdwu2 [ tapIdx ] . im = mnbn5mepwj [ tapIdx ] . re *
muDoubleScalarSin ( alixvjqnkb ) + mnbn5mepwj [ tapIdx ] . im *
muDoubleScalarCos ( alixvjqnkb ) ; _rtDW -> gpwenu31ap [ tapIdx ] += _rtP ->
P_140 * 8.6806E-8 ; } ssCallAccelRunBlock ( S , 7 , 446 , SS_CALL_MDL_OUTPUTS
) ; alixvjqnkb = _rtB -> f04p0h5xcg [ 0 ] . re ; accumulator_im = _rtB ->
f04p0h5xcg [ 0 ] . im ; for ( outBufIdx1 = 0 ; outBufIdx1 < 7 ; outBufIdx1 ++
) { alixvjqnkb += _rtB -> f04p0h5xcg [ outBufIdx1 + 1 ] . re ; accumulator_im
+= _rtB -> f04p0h5xcg [ outBufIdx1 + 1 ] . im ; } _rtB -> bkztmodtfr . re =
alixvjqnkb ; _rtB -> bkztmodtfr . im = accumulator_im ; UNUSED_PARAMETER (
tid ) ; } static void mdlOutputsTID3 ( SimStruct * S , int_T tid ) {
pbkhgmqfhj * _rtB ; kk12dnfhwu * _rtP ; _rtP = ( ( kk12dnfhwu * )
ssGetModelRtp ( S ) ) ; _rtB = ( ( pbkhgmqfhj * ) _ssGetModelBlockIO ( S ) )
; _rtB -> cz0tjnjygm [ 0 ] = _rtP -> P_9 [ 0 ] ; _rtB -> cz0tjnjygm [ 1 ] =
_rtP -> P_9 [ 1 ] ; _rtB -> nnu4uc1syw = _rtP -> P_13 ; _rtB -> hvoemigjvv =
_rtP -> P_16 ; _rtB -> ihoemga42o [ 0 ] = _rtP -> P_25 [ 0 ] ; _rtB ->
ihoemga42o [ 1 ] = _rtP -> P_25 [ 1 ] ; _rtB -> ihoemga42o [ 2 ] = _rtP ->
P_25 [ 2 ] ; _rtB -> ihoemga42o [ 3 ] = _rtP -> P_25 [ 3 ] ; _rtB ->
b1umqs1b4l = _rtP -> P_26 ; _rtB -> ikxig5qnsy = _rtP -> P_27 ; _rtB ->
p3qravtszj = _rtP -> P_28 ; _rtB -> kx2qqzmggx = _rtP -> P_29 ; _rtB ->
btt5uk3us0 = _rtP -> P_30 ; _rtB -> c4ws3q4l4q = _rtP -> P_31 ; _rtB ->
il0tqwy43f = _rtP -> P_32 ; _rtB -> hganx4hmy5 = _rtP -> P_33 ; _rtB ->
iosmpahw4l = _rtP -> P_34 ; _rtB -> cbfxt52wbm = _rtP -> P_35 ; _rtB ->
cw4z5gywbm = _rtP -> P_36 ; _rtB -> m1np00f0rm = _rtP -> P_37 ; _rtB ->
norx5co1uv = _rtP -> P_38 ; _rtB -> bnzivjdbfm = _rtP -> P_39 ; _rtB ->
i4jzjvmrxm = _rtP -> P_40 ; _rtB -> dzivky0xvk = _rtP -> P_41 ; _rtB ->
mintffkybm = _rtP -> P_42 ; _rtB -> iba4x5je4e = _rtP -> P_43 ; _rtB ->
hghymxjfpw = _rtP -> P_44 ; _rtB -> obrtevmtzo = _rtP -> P_45 ; _rtB ->
coz4setksu = _rtP -> P_46 ; _rtB -> g0cphmx0qa = _rtP -> P_47 ; _rtB ->
iax02bnf3g = _rtP -> P_48 ; _rtB -> o1vwpqie15 = _rtP -> P_49 ; _rtB ->
hn1b53l2n0 = _rtP -> P_50 ; _rtB -> k25dprgkln = _rtP -> P_51 ; _rtB ->
fpnpyxwqzv = _rtP -> P_52 ; _rtB -> ixfoetek2s = _rtP -> P_53 ; _rtB ->
avb0vt1iwo = _rtP -> P_54 ; _rtB -> khybymqqhy = _rtP -> P_55 ; _rtB ->
hciuzqgofc = _rtP -> P_56 ; _rtB -> e5ai05cmru = _rtP -> P_57 ; _rtB ->
gqem11lfl1 = _rtP -> P_60 ; _rtB -> ij5smlnheg = _rtP -> P_62 ; _rtB ->
gamnm4smcq = _rtP -> P_64 ; _rtB -> lg2zrguxmj = _rtP -> P_66 ; _rtB ->
jjmaoeqpof = _rtP -> P_68 ; _rtB -> g25qkuykb5 = _rtP -> P_70 ; _rtB ->
osfil5rax0 = _rtP -> P_72 ; _rtB -> o1fq40bg4g = _rtP -> P_74 ; _rtB ->
e4lj2wbbad = _rtP -> P_75 ; _rtB -> i5cflooyjb = _rtP -> P_76 ; _rtB ->
aqi1emzk3x = _rtP -> P_77 ; _rtB -> poez10vfbl = _rtP -> P_78 ; _rtB ->
mtmyhj0pya = _rtP -> P_79 ; _rtB -> drel0c0vue = _rtP -> P_80 ; _rtB ->
a3htuh3v0z = _rtP -> P_81 ; _rtB -> nmccgjqply = _rtP -> P_82 ;
UNUSED_PARAMETER ( tid ) ; }
#define MDL_UPDATE
static void mdlUpdate ( SimStruct * S , int_T tid ) { int32_T idxDelay ;
int32_T idxWidth ; pbkhgmqfhj * _rtB ; i1yaupu10n * _rtDW ; _rtDW = ( (
i1yaupu10n * ) ssGetRootDWork ( S ) ) ; _rtB = ( ( pbkhgmqfhj * )
_ssGetModelBlockIO ( S ) ) ; ssCallAccelRunBlock ( S , 7 , 0 ,
SS_CALL_MDL_UPDATE ) ; if ( ssIsSampleHit ( S , 1 , 0 ) ) { _rtDW ->
flogptrx0i = _rtB -> gny5v15ecw ; } for ( idxDelay = 0 ; idxDelay < 11 ;
idxDelay ++ ) { for ( idxWidth = 0 ; idxWidth < 8 ; idxWidth ++ ) { _rtDW ->
esc5m5vnbf [ ( ( uint32_T ) idxDelay << 3 ) + idxWidth ] = _rtDW ->
esc5m5vnbf [ ( ( idxDelay + 1U ) << 3 ) + idxWidth ] ; } } memcpy ( & _rtDW
-> esc5m5vnbf [ 88 ] , & _rtB -> cp5wlcdwu2 [ 0 ] , sizeof ( creal_T ) << 3U
) ; if ( ssIsSampleHit ( S , 1 , 0 ) ) { ssCallAccelRunBlock ( S , 7 , 8 ,
SS_CALL_MDL_UPDATE ) ; } ssCallAccelRunBlock ( S , 7 , 9 , SS_CALL_MDL_UPDATE
) ; ssCallAccelRunBlock ( S , 7 , 10 , SS_CALL_MDL_UPDATE ) ; if (
ssIsSampleHit ( S , 1 , 0 ) ) { for ( idxDelay = 0 ; idxDelay < 11 ; idxDelay
++ ) { _rtDW -> ecakfpli3v [ ( uint32_T ) idxDelay ] = _rtDW -> ecakfpli3v [
idxDelay + 1U ] ; } _rtDW -> ecakfpli3v [ 11 ] = _rtB -> jw2wm0s2f4 ; }
UNUSED_PARAMETER ( tid ) ; }
#define MDL_UPDATE
static void mdlUpdateTID3 ( SimStruct * S , int_T tid ) { UNUSED_PARAMETER (
tid ) ; } static void mdlInitializeSizes ( SimStruct * S ) { ssSetChecksumVal
( S , 0 , 1352663869U ) ; ssSetChecksumVal ( S , 1 , 3378525191U ) ;
ssSetChecksumVal ( S , 2 , 2494114079U ) ; ssSetChecksumVal ( S , 3 ,
764832904U ) ; { mxArray * slVerStructMat = NULL ; mxArray * slStrMat =
mxCreateString ( "simulink" ) ; char slVerChar [ 10 ] ; int status =
mexCallMATLAB ( 1 , & slVerStructMat , 1 , & slStrMat , "ver" ) ; if ( status
== 0 ) { mxArray * slVerMat = mxGetField ( slVerStructMat , 0 , "Version" ) ;
if ( slVerMat == NULL ) { status = 1 ; } else { status = mxGetString (
slVerMat , slVerChar , 10 ) ; } } mxDestroyArray ( slStrMat ) ;
mxDestroyArray ( slVerStructMat ) ; if ( ( status == 1 ) || ( strcmp (
slVerChar , "8.7" ) != 0 ) ) { return ; } } ssSetOptions ( S ,
SS_OPTION_EXCEPTION_FREE_CODE ) ; if ( ssGetSizeofDWork ( S ) != sizeof (
i1yaupu10n ) ) { ssSetErrorStatus ( S ,
"Unexpected error: Internal DWork sizes do "
"not match for accelerator mex file." ) ; } if ( ssGetSizeofGlobalBlockIO ( S
) != sizeof ( pbkhgmqfhj ) ) { ssSetErrorStatus ( S ,
"Unexpected error: Internal BlockIO sizes do "
"not match for accelerator mex file." ) ; } { int ssSizeofParams ;
ssGetSizeofParams ( S , & ssSizeofParams ) ; if ( ssSizeofParams != sizeof (
kk12dnfhwu ) ) { static char msg [ 256 ] ; sprintf ( msg ,
"Unexpected error: Internal Parameters sizes do "
"not match for accelerator mex file." ) ; } } _ssSetModelRtp ( S , ( real_T *
) & mfglb10ify ) ; rt_InitInfAndNaN ( sizeof ( real_T ) ) ; } static void
mdlInitializeSampleTimes ( SimStruct * S ) { { SimStruct * childS ;
SysOutputFcn * callSysFcns ; childS = ssGetSFunction ( S , 0 ) ; callSysFcns
= ssGetCallSystemOutputFcnList ( childS ) ; callSysFcns [ 3 + 0 ] = (
SysOutputFcn ) ( NULL ) ; } slAccRegPrmChangeFcn ( S , mdlOutputsTID3 ) ; }
static void mdlTerminate ( SimStruct * S ) { }
#include "simulink.c"
