function [Snew, f] = MaskCreation(S,f)
nn = bdroot;
if (size(S,3)==length(f))
    N = size(S,1);
    Y = s2y(S);
    Snew = zeros(size(S));
    for m=1:N
        yn = 0;
        for n = 1:N
            yn = yn+Y(m,n,:);
        end
        Snew(m,m,:)=y2s(yn);
    end
    for m=1:N
        for n=1:m-1
            Snew(m,n,:) = y2s(-Y(m,n,:));
        end
    end
else
    warning('Inconsistent dimensions of S matrix and frequency vector');
end

if strcmp(get_param(nn,'simulationstatus'),'stopped')
    hblock = gcb;
    Simulink.SubSystem.deleteContents(hblock);
    while not(isempty(get_param(hblock,'lines')))
        linelist = get_param(hblock,'lines');
        for idx = 1:numel(linelist),
            delete_line(linelist(idx).Handle);
        end
    end
    createSParametersBlock(Snew,f,hblock);
end

end

